<?php
/**
 * SmartCulto - Visualizar Culto (ADM & Recepcionista)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Get Culto ID from URL
$culto_id = (int)($_GET['id'] ?? 0);

if ($culto_id <= 0) {
    header("Location: listar.php");
    exit();
}

$caminho_cultos = __DIR__ . '/../dados/cultos.json';
$caminho_visitantes = __DIR__ . '/../dados/visitantes.json';

$culto_encontrado = null;
if (file_exists($caminho_cultos)) {
    $cultos = json_decode(file_get_contents($caminho_cultos), true);
    if (is_array($cultos)) {
        foreach ($cultos as $c) {
            if ((int)$c['id'] === $culto_id) {
                $culto_encontrado = $c;
                break;
            }
        }
    }
}

// Block execution if the worship session doesn't exist
if (!$culto_encontrado) {
    header("Location: listar.php");
    exit();
}

// Fetch all visitors associated with this Culto
$visitantes_deste_culto = [];
$total_evangelicos = 0;
$total_nao_evangelicos = 0;

if (file_exists($caminho_visitantes)) {
    $visitantes = json_decode(file_get_contents($caminho_visitantes), true);
    if (is_array($visitantes)) {
        foreach ($visitantes as $v) {
            if (isset($v['culto_id']) && (int)$v['culto_id'] === $culto_id) {
                $visitantes_deste_culto[] = $v;
                if (isset($v['evangelico']) && strcasecmp($v['evangelico'], 'Sim') === 0) {
                    $total_evangelicos++;
                } else {
                    $total_nao_evangelicos++;
                }
            }
        }
    }
}

$num_visitantes = count($visitantes_deste_culto);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Culto #<?php echo $culto_id; ?> - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="calendar" class="w-4 h-4 text-blue-600"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="../visitantes/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Visitantes</span>
                    </a>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="../usuarios/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Usuários (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-500' : 'bg-teal-500'; ?>"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-100 text-indigo-800' : 'bg-teal-100 text-teal-800'; ?>">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="../visitantes/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <?php if ($u_logado['perfil'] === 'ADM'): ?>
            <a href="../usuarios/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
                <span class="text-[10px] font-medium">Usuários</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8 animate-fade-in">
        
        <!-- Breadcrumbs -->
        <nav class="flex mb-6 text-xs font-medium text-slate-400" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="../home.php" class="hover:text-slate-600 flex items-center">
                        <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                        Início
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <a href="listar.php" class="ml-1 md:ml-2 hover:text-slate-600">Cultos</a>
                    </div>
                </li>
                <li aria-current="page">
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <span class="ml-1 md:ml-2 text-slate-500">Detalhes do Culto</span>
                    </div>
                </li>
            </ol>
        </nav>

        <!-- Header Overview Cards -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            
            <!-- Service Identity Card -->
            <div class="lg:col-span-2 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-blue-100 flex flex-col justify-between relative overflow-hidden">
                <div class="absolute -right-8 -bottom-8 opacity-10 text-white pointer-events-none">
                    <i data-lucide="church" class="w-48 h-48"></i>
                </div>
                <div class="relative z-10">
                    <span class="px-2.5 py-1 bg-blue-500/40 text-blue-100 font-bold uppercase tracking-wider text-[10px] rounded-lg">Ficha de Reunião</span>
                    <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2.5 mb-2">
                        <?php echo htmlspecialchars($culto_encontrado['tipo']); ?>
                    </h2>
                    <div class="flex flex-wrap gap-x-6 gap-y-2 mt-4 text-sm text-blue-100 font-medium">
                        <span class="flex items-center">
                            <i data-lucide="calendar" class="w-4 text-blue-300 mr-2"></i>
                            Data: <?php echo date('d/m/Y', strtotime($culto_encontrado['data'])); ?>
                        </span>
                        <span class="flex items-center">
                            <i data-lucide="hash" class="w-4 text-blue-300 mr-2"></i>
                            Identificador único: #<?php echo $culto_id; ?>
                        </span>
                    </div>
                </div>
                
                <div class="relative z-10 flex flex-wrap gap-2 pt-6">
                    <a href="listar.php" class="bg-blue-500 hover:bg-blue-600 text-white border border-blue-400/30 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5">
                        <i data-lucide="alt-arrow-left" class="w-4 h-4"></i>
                        <span>Voltar para Lista</span>
                    </a>
                    
                    <?php if ($u_logado['perfil'] === 'Recepcionista'): ?>
                        <a href="../visitantes/cadastrar.php?culto_id=<?php echo $culto_id; ?>" class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition-all flex items-center space-x-1.5">
                            <i data-lucide="user-plus" class="w-4 h-4"></i>
                            <span>Adicionar Visitante</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Analytics Metric Card -->
            <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
                <div>
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center">
                        <i data-lucide="bar-chart-3" class="w-4 h-4 mr-1.5 text-blue-500"></i>
                        Relatório do Culto
                    </h3>
                    
                    <div class="space-y-4">
                        <div class="flex justify-between items-end border-b border-slate-50 pb-2.5">
                            <span class="text-sm font-medium text-slate-500">Visitantes Inscritos</span>
                            <span class="text-2xl font-extrabold text-slate-800"><?php echo $num_visitantes; ?></span>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4 pt-2">
                            <div class="bg-emerald-50/50 p-3 rounded-2xl border border-emerald-100/50 text-center">
                                <span class="block text-[10px] font-bold text-emerald-700 uppercase">Evangélicos</span>
                                <span class="text-xl font-extrabold text-emerald-800 mt-1 block"><?php echo $total_evangelicos; ?></span>
                            </div>
                            <div class="bg-indigo-50/50 p-3 rounded-2xl border border-indigo-100/50 text-center">
                                <span class="block text-[10px] font-bold text-indigo-700 uppercase">Novas Visitas</span>
                                <span class="text-xl font-extrabold text-indigo-800 mt-1 block"><?php echo $total_nao_evangelicos; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Small progress gauge bar -->
                <div class="pt-4">
                    <span class="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Perfil Religioso de Visitantes</span>
                    <div class="w-full bg-slate-100 h-2.5 rounded-full flex overflow-hidden">
                        <?php if ($num_visitantes > 0): ?>
                            <div class="bg-emerald-500 h-full" style="width: <?php echo ($total_evangelicos / $num_visitantes) * 100; ?>%"></div>
                            <div class="bg-indigo-500 h-full" style="width: <?php echo ($total_nao_evangelicos / $num_visitantes) * 100; ?>%"></div>
                        <?php else: ?>
                            <div class="bg-slate-300 w-full h-full"></div>
                        <?php endif; ?>
                    </div>
                    <div class="flex justify-between items-center text-[10px] text-slate-400 font-medium mt-1">
                        <span class="flex items-center"><span class="w-2 h-2 rounded bg-emerald-500 mr-1.5"></span>Evangélicos</span>
                        <span class="flex items-center">Não Evangélicos<span class="w-2 h-2 rounded bg-indigo-500 ml-1.5"></span></span>
                    </div>
                </div>

            </div>

        </div>

        <!-- Linked Visitors Table -->
        <h3 class="font-bold text-slate-900 text-lg flex items-center mb-4">
            <i data-lucide="users" class="w-5 h-5 mr-1.5 text-blue-600"></i>
            Visitantes na Recepção
        </h3>

        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden mb-8">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-100 text-left">
                    <thead class="bg-slate-50">
                        <tr>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Nome do Visitante</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Membro Evangélico</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Congregação de Origem</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Denominação</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php if (empty($visitantes_deste_culto)): ?>
                            <tr>
                                <td colspan="4" class="px-6 py-12 text-center text-slate-400">
                                    <i data-lucide="user-minus" class="w-8 h-8 mx-auto text-slate-300 mb-2"></i>
                                    <p class="text-sm font-semibold text-slate-600">Nenhum visitante registrado para este culto.</p>
                                    <?php if ($u_logado['perfil'] === 'Recepcionista'): ?>
                                        <a href="../visitantes/cadastrar.php?culto_id=<?php echo $culto_id; ?>" class="inline-block mt-2 text-xs font-semibold text-blue-600 hover:underline">Adicionar o primeiro visitante agora</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($visitantes_deste_culto as $visitor): ?>
                                <tr class="hover:bg-slate-50/55 transition-all w-full">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-blue-50 text-blue-600 mr-3">
                                                <?php echo substr(htmlspecialchars($visitor['nome']), 0,1); ?>
                                            </div>
                                            <span class="text-sm font-bold text-slate-900"><?php echo htmlspecialchars($visitor['nome']); ?></span>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if (isset($visitor['evangelico']) && strcasecmp($visitor['evangelico'], 'Sim') === 0): ?>
                                            <span class="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-md text-xs font-bold tracking-wide inline-flex items-center">
                                                <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
                                                Sim
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-md text-xs font-bold tracking-wide inline-flex items-center">
                                                <i data-lucide="help-circle" class="w-3.5 h-3.5 mr-1"></i>
                                                Não (Visita)
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                                        <?php 
                                            if (isset($visitor['evangelico']) && strcasecmp($visitor['evangelico'], 'Sim') === 0) {
                                                echo htmlspecialchars($visitor['congregacao'] ?? 'Sem registro');
                                            } else {
                                                echo '<span class="text-slate-300 italic">-</span>';
                                            }
                                        ?>
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                                        <?php 
                                            if (isset($visitor['evangelico']) && strcasecmp($visitor['evangelico'], 'Sim') === 0) {
                                                echo htmlspecialchars($visitor['denominacao'] ?? 'Sem registro');
                                            } else {
                                                echo '<span class="text-slate-300 italic">-</span>';
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
