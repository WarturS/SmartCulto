<?php
/**
 * SmartCulto - Cadastrar Culto (Recepcionista only)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Permission check: strictly Recepcionista
if ($u_logado['perfil'] !== 'Recepcionista') {
    header("Location: listar.php");
    exit();
}

$caminho_cultos = __DIR__ . '/../dados/cultos.json';
$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = trim($_POST['tipo'] ?? '');
    $data = trim($_POST['data'] ?? '');

    if (empty($tipo) || empty($data)) {
        $erro = "Por favor, preencha todos os campos do formulário.";
    } else {
        $cultos = [];
        if (file_exists($caminho_cultos)) {
            $cultos = json_decode(file_get_contents($caminho_cultos), true);
            if (!is_array($cultos)) {
                $cultos = [];
            }
        }

        // Auto-increment ID implementation for JSON
        $max_id = 0;
        foreach ($cultos as $c) {
            if (isset($c['id']) && (int)$c['id'] > $max_id) {
                $max_id = (int)$c['id'];
            }
        }
        $novo_id = $max_id + 1;

        $novo_culto = [
            'id' => $novo_id,
            'tipo' => $tipo,
            'data' => $data
        ];

        $cultos[] = $novo_culto;

        if (file_put_contents($caminho_cultos, json_encode($cultos, JSON_PRETTY_PRINT))) {
            $sucesso = "Culto cadastrado com sucesso! Redirecionando para a lista...";
            header("Refresh: 2; url=listar.php");
        } else {
            $erro = "Erro ao gravar as informações no arquivo de dados.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Culto - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="calendar" class="w-4 h-4 text-blue-600"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="../visitantes/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Visitantes</span>
                    </a>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="../usuarios/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Usuários (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full bg-teal-500"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-teal-100 text-teal-800">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="../visitantes/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <?php if ($u_logado['perfil'] === 'ADM'): ?>
            <a href="../usuarios/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
                <span class="text-[10px] font-medium">Usuários</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-2xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8">
        
        <!-- Breadcrumbs -->
        <nav class="flex mb-6 text-xs font-medium text-slate-400" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="../home.php" class="hover:text-slate-600 flex items-center">
                        <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                        Início
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <a href="listar.php" class="ml-1 md:ml-2 hover:text-slate-600">Cultos</a>
                    </div>
                </li>
                <li aria-current="page">
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <span class="ml-1 md:ml-2 text-slate-500">Novo Culto</span>
                    </div>
                </li>
            </ol>
        </nav>

        <?php if (!empty($sucesso)): ?>
            <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl flex items-start space-x-3 text-emerald-800">
                <i data-lucide="check-circle" class="w-5 h-5 mt-0.5 shrink-0 animate-bounce"></i>
                <div class="text-sm font-medium"><?php echo $sucesso; ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($erro)): ?>
            <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-start space-x-3 text-red-800">
                <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                <div class="text-sm font-medium"><?php echo $erro; ?></div>
            </div>
        <?php endif; ?>

        <!-- Form Card -->
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden animate-scale-up">
            <div class="px-6 py-5 bg-slate-50 border-b border-slate-100 flex items-center space-x-2.5">
                <div class="p-2 bg-blue-100 text-blue-600 rounded-lg">
                    <i data-lucide="plus-circle" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-bold text-slate-900">Agendar / Criar Novo Culto</h3>
                    <p class="text-xs text-slate-500">Defina o tipo e a data de ocorrência do culto.</p>
                </div>
            </div>

            <form action="cadastrar.php" method="POST" class="p-6 space-y-5">
                <div>
                    <label for="tipo" class="block text-sm font-semibold text-slate-700">Tipo de Culto</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="book-open" class="w-4 h-4"></i>
                        </div>
                        <input type="text" id="tipo" name="tipo" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                               placeholder="Ex: Culto de Celebração, Culto de Ensino, Reunião de Jovens" value="<?php echo htmlspecialchars($_POST['tipo'] ?? ''); ?>">
                    </div>
                </div>

                <div>
                    <label for="data" class="block text-sm font-semibold text-slate-700">Data de Realização</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="calendar" class="w-4 h-4"></i>
                        </div>
                        <input type="date" id="data" name="data" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all bg-white" 
                               value="<?php echo htmlspecialchars($_POST['data'] ?? date('Y-m-d')); ?>">
                    </div>
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
                    <a href="listar.php" 
                       class="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 focus:outline-none transition-all cursor-pointer">
                        Cancelar
                    </a>
                    <button type="submit" 
                            class="px-5 py-2.5 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                        Confirmar Criação
                    </button>
                </div>
            </form>
        </div>
    </main>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
