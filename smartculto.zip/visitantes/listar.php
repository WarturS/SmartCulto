<?php
/**
 * SmartCulto - Listar Visitantes (ADM & Recepcionista)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

$caminho_visitantes = __DIR__ . '/../dados/visitantes.json';
$caminho_cultos = __DIR__ . '/../dados/cultos.json';

$lista_visitantes = [];
if (file_exists($caminho_visitantes)) {
    $lista_visitantes = json_decode(file_get_contents($caminho_visitantes), true);
    if (!is_array($lista_visitantes)) {
        $lista_visitantes = [];
    }
}

// Build a fast lookup map for Worship Services
$cultos_map = [];
if (file_exists($caminho_cultos)) {
    $lista_cultos = json_decode(file_get_contents($caminho_cultos), true);
    if (is_array($lista_cultos)) {
        foreach ($lista_cultos as $c) {
            $cultos_map[$c['id']] = [
                'tipo' => $c['tipo'],
                'data' => date('d/m/Y', strtotime($c['data']))
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitantes - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="../cultos/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
                        <span>Visitantes</span>
                    </a>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="../usuarios/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Usuários (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-500' : 'bg-teal-500'; ?>"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-100 text-indigo-800' : 'bg-teal-100 text-teal-800'; ?>">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="../cultos/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <?php if ($u_logado['perfil'] === 'ADM'): ?>
            <a href="../usuarios/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
                <span class="text-[10px] font-medium">Usuários</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8 animate-fade-in">

        <!-- Page title & action -->
        <div class="md:flex md:items-center md:justify-between mb-8">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl sm:truncate flex items-center">
                    <i data-lucide="users" class="w-8 h-8 mr-2.5 text-blue-600"></i>
                    Visitantes Acolhidos
                </h2>
                <p class="mt-1 text-sm text-slate-500">Lista geral de visitantes acolhidos pelos recepcionistas em nossa comunidade.</p>
            </div>
            
            <div class="mt-4 flex md:mt-0 md:ml-4">
                <?php if ($u_logado['perfil'] === 'Recepcionista'): ?>
                    <a href="cadastrar.php" class="inline-flex items-center justify-center px-4 py-2.5 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                        <i data-lucide="user-plus" class="w-4 h-4 mr-2"></i>
                        Novo Visitante
                    </a>
                <?php else: ?>
                    <div class="inline-flex items-center space-x-1.5 px-3 py-2 bg-slate-100 text-slate-500 text-xs font-semibold rounded-xl border border-slate-200">
                        <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                        <span>Apenas Recepcionistas adicionam visitantes</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Visitors Listing Card -->
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden mb-8">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-100 text-left">
                    <thead class="bg-slate-50">
                        <tr>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Nome Completo</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Membro Evangélico?</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Congregação / Denominação</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Culto / Encontro Visitado</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php if (empty($lista_visitantes)): ?>
                            <tr>
                                <td colspan="4" class="px-6 py-16 text-center text-slate-400">
                                    <i data-lucide="user-x" class="w-10 h-10 mx-auto text-slate-300 mb-2"></i>
                                    <p class="text-sm font-semibold text-slate-600">Nenhum visitante cadastrado no momento.</p>
                                    <p class="text-xs text-slate-400 mt-1">Utilize o login de Recepcionista para registrar novos visitantes na recepção.</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($lista_visitantes as $visitor): ?>
                                <tr class="hover:bg-slate-50/55 transition-all w-full">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-blue-50 text-blue-600 mr-3">
                                                <?php echo substr(htmlspecialchars($visitor['nome']), 0, 1); ?>
                                            </div>
                                            <span class="text-sm font-bold text-slate-900"><?php echo htmlspecialchars($visitor['nome']); ?></span>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if (isset($visitor['evangelico']) && strcasecmp($visitor['evangelico'], 'Sim') === 0): ?>
                                            <span class="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-md text-xs font-bold tracking-wide inline-flex items-center">
                                                <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
                                                Sim
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-md text-xs font-bold tracking-wide inline-flex items-center">
                                                <i data-lucide="help-circle" class="w-3.5 h-3.5 mr-1"></i>
                                                Não (Visita)
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                                        <?php 
                                            if (isset($visitor['evangelico']) && strcasecmp($visitor['evangelico'], 'Sim') === 0) {
                                                echo '<span class="font-semibold text-slate-700">' . htmlspecialchars($visitor['congregacao'] ?? 'Sem registro') . '</span>';
                                                echo ' <span class="text-[11px] text-slate-400">(' . htmlspecialchars($visitor['denominacao'] ?? 'Outra') . ')</span>';
                                            } else {
                                                echo '<span class="text-slate-300 italic">-</span>';
                                            }
                                        ?>
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <?php 
                                            $c_id = (int)($visitor['culto_id'] ?? 0);
                                            if (isset($cultos_map[$c_id])) {
                                                echo '<a href="../cultos/visualizar.php?id=' . $c_id . '" class="text-blue-600 hover:text-blue-800 underline font-semibold">';
                                                echo htmlspecialchars($cultos_map[$c_id]['tipo']);
                                                echo ' <span class="text-xs font-normal text-slate-400">(' . htmlspecialchars($cultos_map[$c_id]['data']) . ')</span>';
                                                echo '</a>';
                                            } else {
                                                echo '<span class="text-slate-400 italic">Culto ID #' . $c_id . ' (Inexistente)</span>';
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
