<?php
/**
 * SmartCulto - Cadastrar Visitante (Recepcionista only)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Permission check: strictly Recepcionista
if ($u_logado['perfil'] !== 'Recepcionista') {
    header("Location: listar.php");
    exit();
}

$caminho_visitantes = __DIR__ . '/../dados/visitantes.json';
$caminho_cultos = __DIR__ . '/../dados/cultos.json';

$erro = "";
$sucesso = "";

// Pre-fill culto_id from URL query if available
$pre_culto_id = (int)($_GET['culto_id'] ?? 0);

// Load cultos list for dropdown and check if any culto exists
$lista_cultos = [];
if (file_exists($caminho_cultos)) {
    $lista_cultos = json_decode(file_get_contents($caminho_cultos), true);
    if (!is_array($lista_cultos)) {
        $lista_cultos = [];
    }
}

// Order by date descending by default
if (!empty($lista_cultos)) {
    usort($lista_cultos, function($a, $b) {
        return strcmp($b['data'], $a['data']);
    });
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $evangelico = trim($_POST['evangelico'] ?? 'Não');
    $congregacao = trim($_POST['congregacao'] ?? '');
    $denominacao = trim($_POST['denominacao'] ?? '');
    $culto_id = (int)($_POST['culto_id'] ?? 0);

    // Form validation
    if (empty($nome) || $culto_id <= 0) {
        $erro = "Os campos Nome e Culto são de preenchimento obrigatório.";
    } else if ($evangelico === 'Sim' && (empty($congregacao) || empty($denominacao))) {
        $erro = "Ao marcar Sim para evangélico, defina a congregação e a denominação de origem.";
    } else {
        // Double check if target culto actually exists
        $culto_existe = false;
        foreach ($lista_cultos as $c) {
            if ((int)$c['id'] === $culto_id) {
                $culto_existe = true;
                break;
            }
        }

        if (!$culto_existe) {
            $erro = "O culto selecionado não foi encontrado.";
        } else {
            // Read visitors json
            $visitantes = [];
            if (file_exists($caminho_visitantes)) {
                $visitantes = json_decode(file_get_contents($caminho_visitantes), true);
                if (!is_array($visitantes)) {
                    $visitantes = [];
                }
            }

            // Create new visitor
            $novo_visitante = [
                'nome' => $nome,
                'evangelico' => $evangelico,
                'congregacao' => ($evangelico === 'Sim') ? $congregacao : '',
                'denominacao' => ($evangelico === 'Sim') ? $denominacao : '',
                'culto_id' => $culto_id
            ];

            $visitantes[] = $novo_visitante;

            if (file_put_contents($caminho_visitantes, json_encode($visitantes, JSON_PRETTY_PRINT))) {
                $sucesso = "Visitante cadastrado com sucesso! Redirecionando...";
                header("Refresh: 2; url=../cultos/visualizar.php?id=" . $culto_id);
            } else {
                $erro = "Falha ao gravar os dados do visitante no arquivo JSON.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Visitante - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="../cultos/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
                        <span>Visitantes</span>
                    </a>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="../usuarios/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Usuários (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full bg-teal-500"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-teal-100 text-teal-800">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="../cultos/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <?php if ($u_logado['perfil'] === 'ADM'): ?>
            <a href="../usuarios/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
                <span class="text-[10px] font-medium">Usuários</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-2xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8 animate-fade-in">
        
        <!-- Breadcrumbs -->
        <nav class="flex mb-6 text-xs font-medium text-slate-400" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="../home.php" class="hover:text-slate-600 flex items-center">
                        <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                        Início
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <a href="listar.php" class="ml-1 md:ml-2 hover:text-slate-600">Visitantes</a>
                    </div>
                </li>
                <li aria-current="page">
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <span class="ml-1 md:ml-2 text-slate-500">Novo Visitante</span>
                    </div>
                </li>
            </ol>
        </nav>

        <?php if (!empty($sucesso)): ?>
            <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl flex items-start space-x-3 text-emerald-800">
                <i data-lucide="check-circle" class="w-5 h-5 mt-0.5 shrink-0 animate-bounce"></i>
                <div class="text-sm font-medium"><?php echo $sucesso; ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($erro)): ?>
            <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-start space-x-3 text-red-800">
                <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                <div class="text-sm font-medium"><?php echo $erro; ?></div>
            </div>
        <?php endif; ?>

        <?php if (empty($lista_cultos)): ?>
            <!-- Lock Screen if Cultos list is empty -->
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-4 shadow-sm animate-pulse">
                <i data-lucide="calendar-warning" class="w-12 h-12 mx-auto text-amber-500"></i>
                <h3 class="font-bold text-amber-800 text-base">Nenhum Culto Agendado no Banco</h3>
                <p class="text-xs text-amber-700 leading-relaxed max-w-sm mx-auto">
                    Você deve agendar ou cadastrar ao menos um culto no sistema antes de poder associar novos visitantes.
                </p>
                <div>
                    <a href="../cultos/cadastrar.php" class="inline-flex items-center justify-center px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer">
                        <i data-lucide="plus" class="w-4 h-4 mr-1"></i>
                        Cadastrar Primeiro Culto
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Form Card -->
            <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                <div class="px-6 py-5 bg-slate-50 border-b border-slate-100 flex items-center space-x-2.5">
                    <div class="p-2 bg-blue-100 text-blue-600 rounded-lg">
                        <i data-lucide="user-plus" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-900">Acolher & Registrar Visitante</h3>
                        <p class="text-xs text-slate-500">Registre visitantes na recepção e associe-os a um culto ativo.</p>
                    </div>
                </div>

                <form action="cadastrar.php" method="POST" class="p-6 space-y-5">
                    <!-- Name Input -->
                    <div>
                        <label for="nome" class="block text-sm font-semibold text-slate-700">Nome Completo do Visitante</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                <i data-lucide="user" class="w-4 h-4"></i>
                            </div>
                            <input type="text" id="nome" name="nome" required 
                                   class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                                   placeholder="Nome completo do convidado" value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                        </div>
                    </div>

                    <!-- Connection/Worship Dropdown selection -->
                    <div>
                        <label for="culto_id" class="block text-sm font-semibold text-slate-700">Culto de Presença</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                <i data-lucide="church" class="w-4 h-4"></i>
                            </div>
                            <select id="culto_id" name="culto_id" required 
                                    class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all bg-white cursor-pointer select-none">
                                <option value="">Selecione o culto...</option>
                                <?php foreach ($lista_cultos as $culto): ?>
                                    <?php 
                                        $selected = "";
                                        if (isset($_POST['culto_id']) && (int)$_POST['culto_id'] === (int)$culto['id']) {
                                            $selected = "selected";
                                        } else if ($pre_culto_id > 0 && $pre_culto_id === (int)$culto['id']) {
                                            $selected = "selected";
                                        }
                                    ?>
                                    <option value="<?php echo (int)$culto['id']; ?>" <?php echo $selected; ?>>
                                        <?php echo htmlspecialchars($culto['tipo']); ?> - <?php echo date('d/m/Y', strtotime($culto['data'])); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Evangelical select dropdown -->
                    <div>
                        <label for="evangelico" class="block text-sm font-semibold text-slate-700">Convidado é Evangélico?</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                <i data-lucide="sparkles" class="w-4 h-4"></i>
                            </div>
                            <select id="evangelico" name="evangelico" required onchange="toggleReligiaoFields()"
                                    class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all bg-white cursor-pointer select-none">
                                <option value="Não" <?php echo (isset($_POST['evangelico']) && $_POST['evangelico'] === 'Não') ? 'selected' : ''; ?>>Não (Novo Visitante / Convidado)</option>
                                <option value="Sim" <?php echo (isset($_POST['evangelico']) && $_POST['evangelico'] === 'Sim') ? 'selected' : ''; ?>>Sim (Membro de outra congregação)</option>
                            </select>
                        </div>
                    </div>

                    <!-- Evangelical Related Fields wrapper (hidden by default) -->
                    <div id="evangelico-wrapper" class="hidden space-y-5 border-l-2 border-slate-200 pl-4 py-1.5 transition-all">
                        <div>
                            <label for="congregacao" class="block text-sm font-semibold text-slate-700">Congregação de Membresia</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                    <i data-lucide="milestone" class="w-4 h-4"></i>
                                </div>
                                <input type="text" id="congregacao" name="congregacao" 
                                       class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                                       placeholder="Nome da igreja local de origem" value="<?php echo htmlspecialchars($_POST['congregacao'] ?? ''); ?>">
                            </div>
                        </div>

                        <div>
                            <label for="denominacao" class="block text-sm font-semibold text-slate-700">Denominação Religiosa</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                    <i data-lucide="tags" class="w-4 h-4"></i>
                                </div>
                                <input type="text" id="denominacao" name="denominacao" 
                                       class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                                       placeholder="Ex: Assembleia de Deus, Batista, Presbiteriana" value="<?php echo htmlspecialchars($_POST['denominacao'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Action buttons -->
                    <div class="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
                        <a href="listar.php" 
                           class="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 focus:outline-none transition-all cursor-pointer">
                            Cancelar
                        </a>
                        <button type="submit" 
                                class="px-5 py-2.5 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                            Confirmar Registro
                        </button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </main>

    <!-- Lucide icons activator & religion fields toggle scripts -->
    <script>
        lucide.createIcons();

        function toggleReligiaoFields() {
            const select = document.getElementById('evangelico');
            const wrapper = document.getElementById('evangelico-wrapper');
            const inputCong = document.getElementById('congregacao');
            const inputDen = document.getElementById('denominacao');

            if (select.value === 'Sim') {
                wrapper.classList.remove('hidden');
                inputCong.setAttribute('required', 'required');
                inputDen.setAttribute('required', 'required');
            } else {
                wrapper.classList.add('hidden');
                inputCong.removeAttribute('required');
                inputDen.removeAttribute('required');
                inputCong.value = '';
                inputDen.value = '';
            }
        }

        // Run once on page load to restore state if postback error
        window.onload = function() {
            toggleReligiaoFields();
        };
    </script>
</body>
</html>
