<?php
/**
 * SmartCulto - Cadastrar Usuário (ADM only)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Permission check: strictly ADM
if ($u_logado['perfil'] !== 'ADM') {
    header("Location: ../home.php");
    exit();
}

$caminho_usuarios = __DIR__ . '/../dados/usuarios.json';
$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    $perfil = trim($_POST['perfil'] ?? '');

    // Validation
    if (empty($nome) || empty($email) || empty($senha) || empty($perfil)) {
        $erro = "Todos os campos de cadastro são de preenchimento obrigatório.";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = "Por favor, digite um endereço de email válido.";
    } else if ($perfil !== 'ADM' && $perfil !== 'Recepcionista') {
        $erro = "Perfil de acesso inválido.";
    } else {
        // Read existing users to check for duplicate email
        $usuarios = [];
        if (file_exists($caminho_usuarios)) {
            $usuarios = json_decode(file_get_contents($caminho_usuarios), true);
            if (!is_array($usuarios)) {
                $usuarios = [];
            }
        }

        $email_existe = false;
        foreach ($usuarios as $user) {
            if (strcasecmp($user['email'], $email) === 0) {
                $email_existe = true;
                break;
            }
        }

        if ($email_existe) {
            $erro = "Este email já está cadastrado por outro operador.";
        } else {
            // Setup new user object
            $novo_usuario = [
                'nome' => $nome,
                'email' => $email,
                'senha' => password_hash($senha, PASSWORD_BCRYPT),
                'perfil' => $perfil
            ];

            $usuarios[] = $novo_usuario;

            if (file_put_contents($caminho_usuarios, json_encode($usuarios, JSON_PRETTY_PRINT))) {
                $sucesso = "Operador cadastrado com sucesso! Redirecionando para a listagem...";
                // Redirect after 2 seconds to make the success visible
                header("Refresh: 2; url=listar.php");
            } else {
                $erro = "Falha ao gravar os dados do novo operador.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Operador - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="../cultos/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="../visitantes/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Visitantes</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="shield-alert" class="w-4 h-4 text-blue-600"></i>
                        <span>Usuários (ADM)</span>
                    </a>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full bg-indigo-500"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="../cultos/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="../visitantes/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="shield-alert" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Usuários</span>
        </a>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-2xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8">
        
        <!-- Breadcrumbs -->
        <nav class="flex mb-6 text-xs font-medium text-slate-400" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="../home.php" class="hover:text-slate-600 flex items-center">
                        <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                        Início
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <a href="listar.php" class="ml-1 md:ml-2 hover:text-slate-600">Usuários</a>
                    </div>
                </li>
                <li aria-current="page">
                    <div class="flex items-center">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></i>
                        <span class="ml-1 md:ml-2 text-slate-500">Novo Operador</span>
                    </div>
                </li>
            </ol>
        </nav>

        <?php if (!empty($sucesso)): ?>
            <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl flex items-start space-x-3 text-emerald-800">
                <i data-lucide="check-circle" class="w-5 h-5 mt-0.5 shrink-0 animate-bounce"></i>
                <div class="text-sm font-medium"><?php echo $sucesso; ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($erro)): ?>
            <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-start space-x-3 text-red-800">
                <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                <div class="text-sm font-medium"><?php echo $erro; ?></div>
            </div>
        <?php endif; ?>

        <!-- Form Card -->
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div class="px-6 py-5 bg-slate-50 border-b border-slate-100 flex items-center space-x-2.5">
                <div class="p-2 bg-blue-100 text-blue-600 rounded-lg">
                    <i data-lucide="user-plus" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-bold text-slate-900">Cadastrar Novo Operador</h3>
                    <p class="text-xs text-slate-500">Crie credenciais de acesso para recepcionistas ou administradores.</p>
                </div>
            </div>

            <form action="cadastrar.php" method="POST" class="p-6 space-y-5">
                <div>
                    <label for="nome" class="block text-sm font-semibold text-slate-700">Nome Completo</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="user" class="w-4 h-4"></i>
                        </div>
                        <input type="text" id="nome" name="nome" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                               placeholder="João da Silva" value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                    </div>
                </div>

                <div>
                    <label for="email" class="block text-sm font-semibold text-slate-700">Email Acadêmico / Equipe</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="mail" class="w-4 h-4"></i>
                        </div>
                        <input type="email" id="email" name="email" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                               placeholder="joao@igreja.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                </div>

                <div>
                    <label for="senha" class="block text-sm font-semibold text-slate-700">Senha Provisória</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="lock" class="w-4 h-4"></i>
                        </div>
                        <input type="password" id="senha" name="senha" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                               placeholder="Crie uma senha de acesso">
                    </div>
                </div>

                <div>
                    <label for="perfil" class="block text-sm font-semibold text-slate-700">Nível de Permissão (Perfil)</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="badge-check" class="w-4 h-4"></i>
                        </div>
                        <select id="perfil" name="perfil" required 
                                class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all bg-white cursor-pointer select-none">
                            <option value="">Selecione o perfil de atuação...</option>
                            <option value="Recepcionista" <?php echo (isset($_POST['perfil']) && $_POST['perfil'] === 'Recepcionista') ? 'selected' : ''; ?>>Recepcionista (Recepção & Cultos)</option>
                            <option value="ADM" <?php echo (isset($_POST['perfil']) && $_POST['perfil'] === 'ADM') ? 'selected' : ''; ?>>ADM (Administração Completa)</option>
                        </select>
                    </div>
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
                    <a href="listar.php" 
                       class="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 focus:outline-none transition-all cursor-pointer">
                        Cancelar
                    </a>
                    <button type="submit" 
                            class="px-5 py-2.5 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                        Confirmar Cadastro
                    </button>
                </div>
            </form>
        </div>
    </main>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
