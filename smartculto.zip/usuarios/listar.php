<?php
/**
 * SmartCulto - Listar Usuários (ADM only)
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Permission check: strictly ADM
if ($u_logado['perfil'] !== 'ADM') {
    header("Location: ../home.php");
    exit();
}

$caminho_usuarios = __DIR__ . '/../dados/usuarios.json';
$sucesso = "";
$erro = "";

// Redefine password action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'redefinir_senha') {
    $email_redefinir = trim($_POST['email'] ?? '');
    $nova_senha = trim($_POST['nova_senha'] ?? '');

    if (empty($email_redefinir) || empty($nova_senha)) {
        $erro = "Por favor, preencha todos os campos.";
    } else {
        if (file_exists($caminho_usuarios)) {
            $usuarios = json_decode(file_get_contents($caminho_usuarios), true);
            if (!is_array($usuarios)) {
                $usuarios = [];
            }

            $encontrado = false;
            foreach ($usuarios as $idx => $user) {
                if ($user['email'] === $email_redefinir) {
                    // Update password using password_hash for maximum security
                    $usuarios[$idx]['senha'] = password_hash($nova_senha, PASSWORD_BCRYPT);
                    $encontrado = true;
                    break;
                }
            }

            if ($encontrado) {
                if (file_put_contents($caminho_usuarios, json_encode($usuarios, JSON_PRETTY_PRINT))) {
                    $sucesso = "A senha do usuário <strong>" . htmlspecialchars($email_redefinir) . "</strong> foi redefinida com sucesso!";
                } else {
                    $erro = "Falha ao gravar as alterações no arquivo JSON.";
                }
            } else {
                $erro = "Usuário não encontrado.";
            }
        } else {
            $erro = "Arquivo de usuários inexistente.";
        }
    }
}

// Load users listing
$lista_usuarios = [];
if (file_exists($caminho_usuarios)) {
    $lista_usuarios = json_decode(file_get_contents($caminho_usuarios), true);
    if (!is_array($lista_usuarios)) {
        $lista_usuarios = [];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="../home.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                        <span>Início</span>
                    </a>
                    <a href="../cultos/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="../visitantes/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Visitantes</span>
                    </a>
                    <a href="listar.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="shield-alert" class="w-4 h-4 text-blue-600"></i>
                        <span>Usuários (ADM)</span>
                    </a>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full bg-indigo-500"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="../logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="../home.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="../cultos/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="../visitantes/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <a href="listar.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="shield-alert" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Usuários</span>
        </a>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8">
        
        <!-- Success/Error alerts -->
        <?php if (!empty($sucesso)): ?>
            <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl flex items-start space-x-3 text-emerald-800">
                <i data-lucide="check-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                <div class="text-sm font-medium"><?php echo $sucesso; ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($erro)): ?>
            <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-start space-x-3 text-red-800">
                <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                <div class="text-sm font-medium"><?php echo $erro; ?></div>
            </div>
        <?php endif; ?>

        <!-- Page title & action -->
        <div class="md:flex md:items-center md:justify-between mb-8">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl sm:truncate flex items-center">
                    <i data-lucide="users-round" class="w-8 h-8 mr-2.5 text-blue-600"></i>
                    Operadores de Equipe
                </h2>
                <p class="mt-1 text-sm text-slate-500">Gerenciamento de acessos de Administradores e Recepcionistas.</p>
            </div>
            <div class="mt-4 flex md:mt-0 md:ml-4">
                <a href="cadastrar.php" class="inline-flex items-center justify-center px-4 py-2.5 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                    <i data-lucide="user-plus" class="w-4 h-4 mr-2"></i>
                    Registrar Operador
                </a>
            </div>
        </div>

        <!-- Desktop Users list/table table card -->
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden mb-8">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-100 text-left">
                    <thead class="bg-slate-50">
                        <tr>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Nome</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Email</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cargo / Perfil</th>
                            <th scope="col" class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php if (empty($lista_usuarios)): ?>
                            <tr>
                                <td colspan="4" class="px-6 py-12 text-center text-slate-400">
                                    <i data-lucide="info" class="w-8 h-8 mx-auto text-slate-300 mb-2"></i>
                                    <p class="text-sm">Nenhum operador cadastrado no momento.</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($lista_usuarios as $user): ?>
                                <tr class="hover:bg-slate-50/55 transition-all">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-blue-50 text-blue-600 mr-3">
                                                <?php echo substr(htmlspecialchars($user['nome']), 0, 1); ?>
                                            </div>
                                            <span class="text-sm font-semibold text-slate-800"><?php echo htmlspecialchars($user['nome']); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                                        <?php echo htmlspecialchars($user['email']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider <?php echo $user['perfil'] === 'ADM' ? 'bg-indigo-100 text-indigo-800' : 'bg-teal-100 text-teal-800'; ?>">
                                            <?php echo htmlspecialchars($user['perfil']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <button onclick="abrirModalRedefinir('<?php echo htmlspecialchars($user['email']); ?>')" 
                                                class="inline-flex items-center space-x-1 text-xs font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer">
                                            <i data-lucide="key-round" class="w-3.5 h-3.5"></i>
                                            <span>Redefinir Senha</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Reset Password Modal Backdrop -->
    <div id="redefinirModal" class="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 hidden">
        <div class="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden transform scale-95 transition-all" id="modalContainer">
            <div class="px-6 py-5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div class="flex items-center space-x-2 text-slate-900 font-bold">
                    <i data-lucide="key-round" class="w-5 h-5 text-blue-600"></i>
                    <span>Alterar Senha de Operador</span>
                </div>
                <button onclick="fecharModalRedefinir()" class="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-200 transition-all cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form action="listar.php" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="acao" value="redefinir_senha">
                
                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Email do Operador</label>
                    <input type="text" id="modalEmailDisplay" class="block w-full px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-600 text-sm font-semibold focus:outline-none cursor-not-allowed" readonly>
                    <input type="hidden" name="email" id="modalEmailValue">
                </div>

                <div>
                    <label for="nova_senha" class="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Nova Senha</label>
                    <input type="password" id="nova_senha" name="nova_senha" required placeholder="Digite a nova senha de login"
                           class="block w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all">
                </div>

                <div class="flex space-x-3 pt-4 border-t border-slate-100">
                    <button type="button" onclick="fecharModalRedefinir()" 
                            class="flex-1 justify-center py-2.5 px-4 border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 focus:outline-none transition-all cursor-pointer text-center">
                        Cancelar
                    </button>
                    <button type="submit" 
                            class="flex-1 justify-center py-2.5 px-4 border border-transparent rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none transition-all cursor-pointer">
                        Salvar Nova Senha
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Lucide icons activator & modal handler scripts -->
    <script>
        lucide.createIcons();

        function abrirModalRedefinir(email) {
            document.getElementById('modalEmailDisplay').value = email;
            document.getElementById('modalEmailValue').value = email;
            
            const modal = document.getElementById('redefinirModal');
            modal.classList.remove('hidden');
            setTimeout(() => {
                document.getElementById('modalContainer').classList.remove('scale-95');
                document.getElementById('modalContainer').classList.add('scale-100');
            }, 50);
        }

        function fecharModalRedefinir() {
            document.getElementById('modalContainer').classList.remove('scale-100');
            document.getElementById('modalContainer').classList.add('scale-95');
            setTimeout(() => {
                document.getElementById('redefinirModal').classList.add('hidden');
                document.getElementById('nova_senha').value = '';
            }, 200);
        }
    </script>
</body>
</html>
