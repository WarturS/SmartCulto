<?php
/**
 * SmartCulto - Logout Controller
 */
session_start();
session_unset();
session_destroy();

header("Location: login.php");
exit();
?>
