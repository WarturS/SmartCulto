<?php
/**
 * SmartCulto - Login Page
 */
session_start();

// Redirect if already logged in
if (isset($_SESSION['usuario'])) {
    header("Location: home.php");
    exit();
}

$erro = "";

// Check POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if (empty($email) || empty($senha)) {
        $erro = "Por favor, preencha todos os campos.";
    } else {
        $caminho_usuarios = __DIR__ . '/dados/usuarios.json';
        
        if (file_exists($caminho_usuarios)) {
            $usuarios = json_decode(file_get_contents($caminho_usuarios), true);
            if (!is_array($usuarios)) {
                $usuarios = [];
            }
            
            $usuario_encontrado = null;
            foreach ($usuarios as $u) {
                if (strcasecmp($u['email'], $email) === 0) {
                    $usuario_encontrado = $u;
                    break;
                }
            }

            if ($usuario_encontrado) {
                // Verify password: Support both password_verify and plain text fallback (for ease of administration and seeding)
                $hash_valido = false;
                if (password_verify($senha, $usuario_encontrado['senha'])) {
                    $hash_valido = true;
                } else if ($senha === $usuario_encontrado['senha']) {
                    $hash_valido = true;
                }

                if ($hash_valido) {
                    $_SESSION['usuario'] = [
                        'nome' => $usuario_encontrado['nome'],
                        'email' => $usuario_encontrado['email'],
                        'perfil' => $usuario_encontrado['perfil']
                    ];
                    header("Location: home.php");
                    exit();
                } else {
                    $erro = "Senha incorreta.";
                }
            } else {
                $erro = "Usuário não cadastrado.";
            }
        } else {
            $erro = "Banco de dados de usuários não encontrado.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto w-full max-w-md">
        <!-- Logo and Title -->
        <div class="text-center">
            <div class="inline-flex items-center justify-center p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-200 mb-4">
                <i data-lucide="church" class="w-8 h-8"></i>
            </div>
            <h2 class="text-3xl font-extrabold text-slate-900 tracking-tight">SmartCulto</h2>
            <p class="mt-2 text-sm text-slate-500">Gestão de cultos e recepção de visitantes</p>
        </div>
    </div>

    <div class="mt-8 sm:mx-auto w-full max-w-md">
        <div class="bg-white py-8 px-4 shadow-xl border border-slate-100 sm:rounded-2xl sm:px-10">
            
            <?php if (!empty($erro)): ?>
                <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg flex items-start space-x-3 text-red-800 animate-pulse" id="error-alert">
                    <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                    <div>
                        <p class="text-sm font-medium"><?php echo htmlspecialchars($erro); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <form class="space-y-6" action="login.php" method="POST">
                <div>
                    <label for="email" class="block text-sm font-medium text-slate-700">Email</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="mail" class="w-5 h-5"></i>
                        </div>
                        <input id="email" name="email" type="email" autocomplete="email" required 
                            class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                            placeholder="exemplo@igreja.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                </div>

                <div>
                    <div class="flex items-center justify-between">
                        <label for="senha" class="block text-sm font-medium text-slate-700">Senha</label>
                    </div>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="lock" class="w-5 h-5"></i>
                        </div>
                        <input id="senha" name="senha" type="password" autocomplete="current-password" required 
                            class="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all" 
                            placeholder="••••••••">
                    </div>
                </div>

                <div>
                    <button type="submit" 
                        class="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-100 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all cursor-pointer">
                        Acessar o Painel
                    </button>
                </div>
            </form>

            <!-- Seed credentials box for helper -->
            <div class="mt-8 border-t border-slate-100 pt-6">
                <h4 class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center">
                    <i data-lucide="key" class="w-4 h-4 mr-1.5 text-blue-500"></i>
                    Credenciais de Demonstração
                </h4>
                <div class="space-y-2.5 text-xs text-slate-600">
                    <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex justify-between items-center">
                        <div>
                            <span class="font-bold text-slate-700">Perfil ADM:</span>
                            <span class="block text-slate-500">adm@smartculto.com / admin</span>
                        </div>
                        <span class="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md font-semibold text-[10px]">Administrador</span>
                    </div>
                    <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex justify-between items-center">
                        <div>
                            <span class="font-bold text-slate-700">Recepcionista:</span>
                            <span class="block text-slate-500">recep@smartculto.com / recep</span>
                        </div>
                        <span class="px-2 py-0.5 bg-teal-50 text-teal-700 rounded-md font-semibold text-[10px]">Recepcionista</span>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
