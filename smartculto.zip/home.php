<?php
/**
 * SmartCulto - Dashboard Home
 */
session_start();

// Protection layer
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$u_logado = $_SESSION['usuario'];

// Load data for analytics cards
$num_usuarios = 0;
$num_cultos = 0;
$num_visitantes = 0;

$caminho_u = __DIR__ . '/dados/usuarios.json';
$caminho_c = __DIR__ . '/dados/cultos.json';
$caminho_v = __DIR__ . '/dados/visitantes.json';

if (file_exists($caminho_u)) {
    $us = json_decode(file_get_contents($caminho_u), true);
    $num_usuarios = is_array($us) ? count($us) : 0;
}
if (file_exists($caminho_c)) {
    $cu = json_decode(file_get_contents($caminho_c), true);
    $num_cultos = is_array($cu) ? count($cu) : 0;
}
if (file_exists($caminho_v)) {
    $vi = json_decode(file_get_contents($caminho_v), true);
    $num_visitantes = is_array($vi) ? count($vi) : 0;
}

// Get the 3 most recent cults
$recent_cultos = [];
if (file_exists($caminho_c)) {
    $todos_cultos = json_decode(file_get_contents($caminho_c), true);
    if (is_array($todos_cultos)) {
        // Sort by date descending (assuming standard format or string comparison, newer dates are greater strings)
        usort($todos_cultos, function($a, $b) {
            return strcmp($b['data'], $a['data']);
        });
        $recent_cultos = array_slice($todos_cultos, 0, 3);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SmartCulto</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col">

    <!-- Navbar standard -->
    <nav class="bg-white border-b border-slate-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center space-x-3">
                    <div class="flex-shrink-0 flex items-center bg-blue-600 text-white p-2 rounded-xl">
                        <i data-lucide="church" class="w-5 h-5"></i>
                    </div>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">SmartCulto</span>
                </div>

                <!-- Center/Navigation according to role -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="home.php" class="border-b-2 border-blue-600 text-slate-900 px-1 pt-1 text-sm font-semibold flex items-center space-x-1.5 h-full">
                        <i data-lucide="layout-dashboard" class="w-4 h-4 text-blue-600"></i>
                        <span>Início</span>
                    </a>
                    <a href="cultos/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Cultos</span>
                    </a>
                    <a href="visitantes/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Visitantes</span>
                    </a>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="usuarios/listar.php" class="border-b-2 border-transparent text-slate-500 hover:text-slate-950 hover:border-slate-300 px-1 pt-1 text-sm font-medium flex items-center space-x-1.5 h-full transition-all">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Usuários (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
                        <div class="w-2.5 h-2.5 rounded-full <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-500' : 'bg-teal-500'; ?>"></div>
                        <span class="text-xs font-semibold text-slate-700 max-w-[120px] truncate"><?php echo htmlspecialchars($u_logado['nome']); ?></span>
                        <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded <?php echo $u_logado['perfil'] === 'ADM' ? 'bg-indigo-100 text-indigo-800' : 'bg-teal-100 text-teal-800'; ?>">
                            <?php echo $u_logado['perfil']; ?>
                        </span>
                    </div>
                    <a href="logout.php" class="text-slate-400 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all flex items-center space-x-1" title="Sair do sistema">
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span class="hidden sm:inline text-xs font-medium">Sair</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Tab Bar for mobile devices -->
    <div class="md:hidden bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 z-50 py-2 px-4 flex justify-around">
        <a href="home.php" class="flex flex-col items-center space-y-0.5 text-blue-600">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Início</span>
        </a>
        <a href="cultos/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="calendar" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Cultos</span>
        </a>
        <a href="visitantes/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span class="text-[10px] font-medium">Visitantes</span>
        </a>
        <?php if ($u_logado['perfil'] === 'ADM'): ?>
            <a href="usuarios/listar.php" class="flex flex-col items-center space-y-0.5 text-slate-500">
                <i data-lucide="shield-alert" class="w-5 h-5"></i>
                <span class="text-[10px] font-medium">Usuários</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8">
        <!-- Header Hero section -->
        <div class="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-blue-100 mb-8 relative overflow-hidden">
            <div class="absolute -right-16 -bottom-16 opacity-10 text-white pointer-events-none">
                <i data-lucide="church" class="w-96 h-96"></i>
            </div>
            <div class="relative z-10 max-w-2xl">
                <h1 class="text-2xl sm:text-3.5xl font-extrabold tracking-tight mb-2">Bem-vindo ao SmartCulto!</h1>
                <p class="text-blue-100 text-sm sm:text-base mb-6">Simplificando o registro de presenças e acolhimento em sua comunidade de fé.</p>
                <div class="flex flex-wrap gap-3">
                    <?php if ($u_logado['perfil'] === 'Recepcionista'): ?>
                        <a href="cultos/cadastrar.php" class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-all flex items-center space-x-2">
                            <i data-lucide="plus-circle" class="w-4 h-4"></i>
                            <span>Criar Novo Culto</span>
                        </a>
                        <a href="visitantes/cadastrar.php" class="bg-blue-500 hover:bg-blue-600 text-white border border-blue-400/30 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-all flex items-center space-x-2">
                            <i data-lucide="user-plus" class="w-4 h-4"></i>
                            <span>Registrar Visitante</span>
                        </a>
                    <?php else: ?>
                        <a href="usuarios/cadastrar.php" class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-all flex items-center space-x-2">
                            <i data-lucide="user-plus" class="w-4 h-4"></i>
                            <span>Cadastrar Novo Usuário</span>
                        </a>
                        <a href="usuarios/listar.php" class="bg-blue-500 hover:bg-blue-600 text-white border border-blue-400/30 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-all flex items-center space-x-2">
                            <i data-lucide="shield-alert" class="w-4 h-4"></i>
                            <span>Gerenciar Acessos (ADM)</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Metrics Bento Grid -->
        <h2 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4 flex items-center">
            <i data-lucide="activity" class="w-4 h-4 mr-1.5 text-blue-500"></i>
            Métricas Gerais do Sistema
        </h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <!-- Cultos card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                <div class="space-y-1">
                    <p class="text-sm font-medium text-slate-400">Total de Cultos</p>
                    <p class="text-3xl font-extrabold text-slate-900"><?php echo $num_cultos; ?></p>
                    <a href="cultos/listar.php" class="text-xs text-blue-600 hover:text-blue-700 font-semibold inline-flex items-center space-x-1 pt-1">
                        <span>Ver todos</span>
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
                <div class="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                    <i data-lucide="calendar" class="w-8 h-8"></i>
                </div>
            </div>

            <!-- Visitantes card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                <div class="space-y-1">
                    <p class="text-sm font-medium text-slate-400">Total de Visitantes</p>
                    <p class="text-3xl font-extrabold text-slate-900"><?php echo $num_visitantes; ?></p>
                    <a href="visitantes/listar.php" class="text-xs text-blue-600 hover:text-blue-700 font-semibold inline-flex items-center space-x-1 pt-1">
                        <span>Ver todos</span>
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
                <div class="p-3 bg-teal-50 text-teal-600 rounded-2xl">
                    <i data-lucide="users" class="w-8 h-8"></i>
                </div>
            </div>

            <!-- Usuarios card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition-all sm:col-span-2 lg:col-span-1">
                <div class="space-y-1">
                    <p class="text-sm font-medium text-slate-400">Operadores Ativos</p>
                    <p class="text-3xl font-extrabold text-slate-900"><?php echo $num_usuarios; ?></p>
                    <?php if ($u_logado['perfil'] === 'ADM'): ?>
                        <a href="usuarios/listar.php" class="text-xs text-indigo-600 hover:text-indigo-700 font-semibold inline-flex items-center space-x-1 pt-1">
                            <span>Gerenciar equipe</span>
                            <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                        </a>
                    <?php else: ?>
                        <p class="text-xs text-slate-500 italic pt-1 flex items-center">
                            <i data-lucide="lock" class="w-3 h-3 mr-1"></i> Restrito ao ADM
                        </p>
                    <?php endif; ?>
                </div>
                <div class="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                    <i data-lucide="users-round" class="w-8 h-8"></i>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-5 gap-8">
            <!-- Left grid - Recent worships -->
            <div class="lg:col-span-3 space-y-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-slate-900 text-lg flex items-center">
                        <i data-lucide="calendar-days" class="w-5 h-5 mr-1.5 text-blue-600"></i>
                        Cultos Recentes
                    </h3>
                    <a href="cultos/listar.php" class="text-sm font-semibold text-blue-600 hover:text-blue-700">Ver Lista Completa</a>
                </div>

                <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden divide-y divide-slate-100">
                    <?php if (empty($recent_cultos)): ?>
                        <div class="p-8 text-center text-slate-400 space-y-2">
                            <i data-lucide="info" class="w-8 h-8 mx-auto text-slate-300"></i>
                            <p class="text-sm">Nenhum culto cadastrado ainda.</p>
                            <?php if ($u_logado['perfil'] === 'Recepcionista'): ?>
                                <a href="cultos/cadastrar.php" class="inline-block mt-2 text-xs font-semibold text-blue-600 hover:underline">Cadastrar o primeiro culto agora</a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <?php foreach($recent_cultos as $c): ?>
                            <div class="p-5 hover:bg-slate-50 transition-all flex justify-between items-center">
                                <div class="space-y-1">
                                    <h4 class="font-bold text-slate-800 text-base"><?php echo htmlspecialchars($c['tipo']); ?></h4>
                                    <div class="flex items-center space-x-4 text-xs text-slate-500">
                                        <span class="flex items-center">
                                            <i data-lucide="calendar" class="w-3.5 h-3.5 mr-1"></i>
                                            <?php echo date('d/m/Y', strtotime($c['data'])); ?>
                                        </span>
                                        <span class="flex items-center">
                                            <i data-lucide="hash" class="w-3.5 h-3.5 mr-1"></i>
                                            ID: <?php echo htmlspecialchars($c['id']); ?>
                                        </span>
                                    </div>
                                </div>
                                <div>
                                    <a href="cultos/visualizar.php?id=<?php echo urlencode($c['id']); ?>" 
                                       class="p-2 border border-slate-200 text-slate-500 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50/50 rounded-xl transition-all cursor-pointer inline-flex items-center justify-center"
                                       title="Ver detalhes e visitantes">
                                        <i data-lucide="eye" class="w-4 h-4"></i>
                                        <span class="ml-1 text-xs font-semibold hidden sm:inline">Visualizar</span>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right grid - Permissoes / System manual quick links -->
            <div class="lg:col-span-2 space-y-4">
                <h3 class="font-bold text-slate-900 text-lg flex items-center">
                    <i data-lucide="terminal" class="w-5 h-5 mr-1.5 text-blue-600"></i>
                    Suas Permissões Ativas
                </h3>
                <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                    <div class="flex items-center space-x-3 pb-4 border-b border-slate-100">
                        <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                            <?php echo substr($u_logado['perfil'], 0, 1); ?>
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-slate-800"><?php echo htmlspecialchars($u_logado['nome']); ?></p>
                            <p class="text-xs text-slate-400"><?php echo htmlspecialchars($u_logado['email']); ?></p>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Painel de Acesso</p>
                        
                        <?php if ($u_logado['perfil'] === 'ADM'): ?>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Gestão de Operadores</strong>: Listar e registrar novos usuários.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Redefinição de Senhas</strong>: Redefinir senhas dos operadores das equipes.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Consulta Completa</strong>: Visualizar cultos, detalhes e relatórios de visitantes.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="x" class="w-4 h-4 text-red-500 mt-0.5"></i>
                                <span class="text-slate-400"><strong>Criação de Cultos / Visitantes</strong>: Função exclusiva do perfil <i>Recepcionista</i>.</span>
                            </div>
                        <?php else: // Recepcionista ?>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Criação de Cultos</strong>: Registrar novos cultos da igreja.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Recepção de Visitantes</strong>: Cadastrar e vincular novos visitantes ao culto.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 text-emerald-500 mt-0.5"></i>
                                <span><strong>Consulta e Listas</strong>: Visualizar dados e cultos registrados.</span>
                            </div>
                            <div class="flex space-x-2.5 items-start text-xs text-slate-600">
                                <i data-lucide="x" class="w-4 h-4 text-red-500 mt-0.5"></i>
                                <span class="text-slate-400"><strong>Gestão de Operadores</strong>: Função restrita ao perfil <i>ADM</i>.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Lucide icons activator -->
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
