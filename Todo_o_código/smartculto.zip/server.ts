import express from 'express';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';

const app = express();
const PORT = 3000;

// Setup JSON body parsing and URLencoded parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve assets directory directly
app.use('/assets', express.static(path.join(process.cwd(), 'assets')));

// Custom cookie parsing middleware
app.use((req: any, res, next) => {
  const cookieHeader = req.headers.cookie || '';
  const cookies: { [key: string]: string } = {};
  cookieHeader.split(';').forEach((cookie: string) => {
    const trimmed = cookie.trim();
    if (!trimmed) return;
    const index = trimmed.indexOf('=');
    if (index !== -1) {
      const key = trimmed.substring(0, index).trim();
      let val = trimmed.substring(index + 1).trim();
      
      // Strip wrapping double quotes if present (standard cookie specification allows this)
      if (val.startsWith('"') && val.endsWith('"') && val.length > 1) {
        val = val.substring(1, val.length - 1);
      }
      
      try {
        cookies[key] = decodeURIComponent(val);
      } catch (e) {
        cookies[key] = val;
      }
    }
  });
  req.cookies = cookies;
  next();
});

// Helper: load session from cookie or query param
function getSessionUser(req: any) {
  // Try from query parameter first (highly reliable for iframe-blocked environments)
  if (req.query && req.query.usuario_session) {
    try {
      return JSON.parse(decodeURIComponent(req.query.usuario_session as string));
    } catch (e) {}
  }

  if (req.cookies && req.cookies.usuario) {
    try {
      let rawVal = req.cookies.usuario;
      if (typeof rawVal === 'string') {
        rawVal = rawVal.trim();
        // Remove surrounding quotes if the parsed string is still wrapped in them
        if (rawVal.startsWith('"') && rawVal.endsWith('"') && rawVal.length > 1) {
          rawVal = rawVal.substring(1, rawVal.length - 1);
        }
        // Strip Express JSON cookie prefix "j:" if present
        if (rawVal.startsWith('j:')) {
          rawVal = rawVal.substring(2);
        }
        return JSON.parse(rawVal);
      }
      return rawVal;
    } catch (e) {
      return null;
    }
  }
  return null;
}

// Helper: Read JSON DB
function readJsonDB(filename: string): any[] {
  const filePath = path.join(process.cwd(), 'dados', filename);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content) || [];
  } catch (e) {
    return [];
  }
}

// Helper: Write JSON DB
function writeJsonDB(filename: string, data: any[]): boolean {
  const filePath = path.join(process.cwd(), 'dados', filename);
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (e) {
    return false;
  }
}

// Auto-migration for user passwords to new requirements
(function migratePasswords() {
  const file = 'usuarios.json';
  const data = readJsonDB(file);
  let dirty = false;
  data.forEach((u: any) => {
    if (u.email.toLowerCase() === 'adm@smartculto.com') {
      if (!bcrypt.compareSync('admin2026', u.senha)) {
        u.senha = bcrypt.hashSync('admin2026', 10);
        dirty = true;
      }
    } else if (u.email.toLowerCase() === 'recep@smartculto.com') {
      if (!bcrypt.compareSync('recep2026', u.senha)) {
        u.senha = bcrypt.hashSync('recep2026', 10);
        dirty = true;
      }
    }
  });
  if (dirty) {
    writeJsonDB(file, data);
  }
})();

// Helper: Format Date: YYYY-MM-DD -> DD/MM/YYYY
function formatDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

// Custom Common Layout Renders
function renderHeader(user: any, activeTab: string, relativePath: string = ''): string {
  const basePrefix = relativePath ? relativePath + '/' : '';
  const homePath = `${basePrefix}home.php`;
  const cultosPath = `${basePrefix}cultos/listar.php`;
  const visitantesPath = `${basePrefix}visitantes/listar.php`;
  const usuariosPath = `${basePrefix}usuarios/listar.php`;
  const logoutPath = `${basePrefix}logout.php`;
  const stylePath = `${basePrefix}assets/css/style.css`;

  const isHome = activeTab === 'home' ? 'border-b-2 border-zinc-900 text-zinc-950 font-semibold' : 'border-b-2 border-transparent text-zinc-500 hover:text-zinc-950 hover:border-zinc-300';
  const isCultos = activeTab === 'cultos' ? 'border-b-2 border-zinc-900 text-zinc-950 font-semibold' : 'border-b-2 border-transparent text-zinc-500 hover:text-zinc-950 hover:border-zinc-300';
  const isVisitantes = activeTab === 'visitantes' ? 'border-b-2 border-zinc-900 text-zinc-950 font-semibold' : 'border-b-2 border-transparent text-zinc-500 hover:text-zinc-950 hover:border-zinc-300';
  const isUsuarios = activeTab === 'usuarios' ? 'border-b-2 border-zinc-900 text-zinc-950 font-semibold' : 'border-b-2 border-transparent text-zinc-500 hover:text-zinc-950 hover:border-zinc-300';

  const isHomeMobile = activeTab === 'home' ? 'text-zinc-900 font-semibold' : 'text-zinc-400';
  const isCultosMobile = activeTab === 'cultos' ? 'text-zinc-900 font-semibold' : 'text-zinc-400';
  const isVisitantesMobile = activeTab === 'visitantes' ? 'text-zinc-900 font-semibold' : 'text-zinc-400';
  const isUsuariosMobile = activeTab === 'usuarios' ? 'text-zinc-900 font-semibold' : 'text-zinc-400';

  const userRoleBadge = user.perfil === 'ADM' ? 'bg-zinc-100 text-zinc-800 border-zinc-200' : 'bg-zinc-50 text-zinc-700 border-zinc-200';
  const userRoleIndicator = user.perfil === 'ADM' ? 'bg-zinc-800' : 'bg-zinc-400';

  return `
  <!DOCTYPE html>
  <html lang="pt-BR">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>SmartCulto</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="${stylePath}">
      <script src="https://unpkg.com/lucide@latest"></script>
      <script>
          // Automatic iframe-friendly session param injection
          (function() {
              const urlParams = new URLSearchParams(window.location.search);
              let session = urlParams.get('usuario_session');
              
              if (session) {
                  localStorage.setItem('usuario_session', session);
              } else {
                  session = localStorage.getItem('usuario_session');
                  if (session) {
                      urlParams.set('usuario_session', session);
                      window.location.search = urlParams.toString();
                  }
              }
              
              // Automatically append session parameters when DOM is ready
              document.addEventListener('DOMContentLoaded', function() {
                  const currentSession = localStorage.getItem('usuario_session');
                  if (!currentSession) return;
                  
                  // Modify all anchor tags
                  document.querySelectorAll('a').forEach(function(el) {
                      const href = el.getAttribute('href');
                      if (href && !href.startsWith('http') && !href.startsWith('#') && !href.startsWith('javascript:')) {
                          try {
                              const url = new URL(href, window.location.origin);
                              url.searchParams.set('usuario_session', currentSession);
                              el.setAttribute('href', url.pathname + url.search + url.hash);
                          } catch(e) {}
                      }
                  });
                  
                  // Modify all forms
                  document.querySelectorAll('form').forEach(function(el) {
                      const method = (el.getAttribute('method') || 'GET').toUpperCase();
                      if (method === 'GET') {
                          let input = el.querySelector('input[name="usuario_session"]');
                          if (!input) {
                              input = document.createElement('input');
                              input.setAttribute('type', 'hidden');
                              input.setAttribute('name', 'usuario_session');
                              el.appendChild(input);
                          }
                          input.value = currentSession;
                      } else {
                          const action = el.getAttribute('action') || window.location.pathname;
                          try {
                              const url = new URL(action, window.location.origin);
                              url.searchParams.set('usuario_session', currentSession);
                              el.setAttribute('action', url.pathname + url.search + url.hash);
                          } catch(e) {}
                      }
                  });
              });
          })();
      </script>
      <script>
          tailwind.config = {
              theme: {
                  extend: {
                      fontFamily: {
                          sans: ['Inter', 'sans-serif'],
                      }
                  }
              }
          }
      </script>
  </head>
  <body class="bg-[#F8F9FA] min-h-screen text-zinc-800 flex flex-col">
      <nav class="bg-white/95 backdrop-blur-md border-b border-zinc-200/50 sticky top-0 z-50">
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div class="flex justify-between h-16">
                  <div class="flex items-center space-x-3">
                      <div class="flex-shrink-0 flex items-center bg-zinc-950 text-white p-2 rounded-xl">
                          <i data-lucide="church" class="w-5 h-5"></i>
                      </div>
                      <span class="text-xl font-bold text-zinc-900 tracking-tight">SmartCulto</span>
                  </div>

                  <div class="hidden md:flex space-x-8 items-center h-full">
                      <a href="${homePath}" class="${isHome} px-1 pt-1 text-sm flex items-center space-x-1.5 h-full transition-all">
                          <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                          <span>Início</span>
                      </a>
                      <a href="${cultosPath}" class="${isCultos} px-1 pt-1 text-sm flex items-center space-x-1.5 h-full transition-all">
                          <i data-lucide="calendar" class="w-4 h-4"></i>
                          <span>Cultos</span>
                      </a>
                      <a href="${visitantesPath}" class="${isVisitantes} px-1 pt-1 text-sm flex items-center space-x-1.5 h-full transition-all">
                          <i data-lucide="users" class="w-4 h-4"></i>
                          <span>Visitantes</span>
                      </a>
                      ${user.perfil === 'ADM' ? `
                      <a href="${usuariosPath}" class="${isUsuarios} px-1 pt-1 text-sm flex items-center space-x-1.5 h-full transition-all">
                          <i data-lucide="shield-alert" class="w-4 h-4"></i>
                          <span>Usuários</span>
                      </a>
                      ` : ''}
                  </div>

                  <div class="flex items-center space-x-4">
                      <div class="flex items-center space-x-2 bg-zinc-50 px-3 py-1.5 rounded-xl border border-zinc-200/60">
                          <div class="w-2.5 h-2.5 rounded-full ${userRoleIndicator}"></div>
                          <span class="text-xs font-semibold text-zinc-700 max-w-[120px] truncate">${user.nome}</span>
                          <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded border ${userRoleBadge}">
                              ${user.perfil}
                          </span>
                      </div>
                      <a href="${logoutPath}" class="text-zinc-400 hover:text-zinc-900 p-2 rounded-xl hover:bg-zinc-100 transition-all flex items-center space-x-1">
                          <i data-lucide="log-out" class="w-5 h-5"></i>
                          <span class="hidden sm:inline text-xs font-medium">Sair</span>
                      </a>
                  </div>
              </div>
          </div>
      </nav>

      <div class="md:hidden bg-white/95 backdrop-blur-md border-t border-zinc-100 fixed bottom-0 left-0 right-0 z-50 py-2.5 px-4 flex justify-around">
          <a href="${homePath}" class="flex flex-col items-center space-y-0.5 ${isHomeMobile}">
              <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
              <span class="text-[10px] font-medium">Início</span>
          </a>
          <a href="${cultosPath}" class="flex flex-col items-center space-y-0.5 ${isCultosMobile}">
              <i data-lucide="calendar" class="w-5 h-5"></i>
              <span class="text-[10px] font-medium">Cultos</span>
          </a>
          <a href="${visitantesPath}" class="flex flex-col items-center space-y-0.5 ${isVisitantesMobile}">
              <i data-lucide="users" class="w-5 h-5"></i>
              <span class="text-[10px] font-medium">Visitantes</span>
          </a>
          ${user.perfil === 'ADM' ? `
          <a href="${usuariosPath}" class="flex flex-col items-center space-y-0.5 ${isUsuariosMobile}">
              <i data-lucide="shield-alert" class="w-5 h-5"></i>
              <span class="text-[10px] font-medium">Usuários</span>
          </a>
          ` : ''}
      </div>

      <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20 md:mb-8">
  `;
}

function renderFooter(): string {
  return `
      </main>
      <script>
          lucide.createIcons();
      </script>
  </body>
  </html>
  `;
}

// -------------------------------------------------------------
// APP ROUTES PORTRAYING PHP PAGES BEHAVIOR
// -------------------------------------------------------------

// Root redirect
app.get(['/', '/index.php'], (req, res) => {
  const user = getSessionUser(req);
  if (user) {
    res.redirect('/home.php');
  } else {
    res.redirect('/login.php');
  }
});

// Logout Handler
app.get('/logout.php', (req, res) => {
  res.clearCookie('usuario', { path: '/' });
  res.redirect('/login.php');
});

// LOGIN PAGE
app.get('/login.php', (req: any, res) => {
  const user = getSessionUser(req);
  if (user) {
    return res.redirect('/home.php');
  }

  const erro = req.query.erro ? decodeURIComponent(req.query.erro as string) : '';
  const preEmail = req.query.email ? decodeURIComponent(req.query.email as string) : '';

  res.send(`
  <!DOCTYPE html>
  <html lang="pt-BR">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login - SmartCulto</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
      <script src="https://unpkg.com/lucide@latest"></script>
      <script>
          // Since we are back on the login page, clear any previous cached session parameter
          localStorage.removeItem('usuario_session');
      </script>
  </head>
  <body class="bg-[#F8F9FA] min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div class="sm:mx-auto w-full max-w-md">
          <div class="text-center">
              <div class="inline-flex items-center justify-center p-3 bg-zinc-950 rounded-2xl text-white mb-4">
                  <i data-lucide="church" class="w-8 h-8"></i>
              </div>
              <h2 class="text-3xl font-extrabold text-zinc-900 tracking-tight">SmartCulto</h2>
              <p class="mt-2 text-sm text-zinc-500">Gestão de cultos e recepção de visitantes</p>
          </div>
      </div>

      <div class="mt-8 sm:mx-auto w-full max-w-md">
          <div class="bg-white py-8 px-4 border border-zinc-200/60 shadow-xs sm:rounded-2xl sm:px-10">
              
              ${erro ? `
                  <div class="mb-6 p-4 bg-red-50/60 border-l-4 border-red-500 rounded-r-lg flex items-start space-x-3 text-red-800">
                      <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
                      <div>
                          <p class="text-sm font-medium">${erro}</p>
                      </div>
                  </div>
              ` : ''}

              <form class="space-y-6" action="/login.php" method="POST">
                  <div>
                      <label for="email" class="block text-sm font-medium text-zinc-700">Email</label>
                      <div class="mt-1 relative rounded-md shadow-sm">
                          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                              <i data-lucide="mail" class="w-5 h-5"></i>
                          </div>
                          <input id="email" name="email" type="email" autocomplete="email" required 
                              class="block w-full pl-10 pr-3 py-2.5 border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900 focus:border-zinc-900 text-sm transition-all bg-zinc-50/20" 
                              placeholder="exemplo@igreja.com" value="${preEmail}">
                      </div>
                  </div>

                  <div>
                      <label for="senha" class="block text-sm font-medium text-zinc-700">Senha</label>
                      <div class="mt-1 relative rounded-md shadow-sm">
                          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                              <i data-lucide="lock" class="w-5 h-5"></i>
                          </div>
                          <input id="senha" name="senha" type="password" autocomplete="current-password" required 
                              class="block w-full pl-10 pr-3 py-2.5 border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900 focus:border-zinc-900 text-sm transition-all bg-zinc-50/20" 
                              placeholder="••••••••">
                      </div>
                  </div>

                  <div>
                      <button type="submit" 
                          class="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-900 transition-all cursor-pointer shadow-xs">
                          Acessar o Painel
                      </button>
                  </div>
              </form>

              <div class="mt-8 border-t border-zinc-100 pt-6">
                  <h4 class="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3 flex items-center">
                      <i data-lucide="key" class="w-4 h-4 mr-1.5 text-zinc-800"></i>
                      Credenciais de Demonstração
                  </h4>
                  <div class="space-y-2.5 text-xs text-zinc-650">
                      <div class="bg-zinc-50/80 p-2.5 rounded-xl border border-zinc-200/50 flex justify-between items-center">
                          <div>
                              <span class="font-bold text-zinc-700">Perfil ADM:</span>
                              <span class="block text-zinc-500">adm@smartculto.com / admin2026</span>
                          </div>
                          <span class="px-2 py-0.5 bg-zinc-100 text-zinc-800 border border-zinc-200 rounded-md font-semibold text-[10px]">Administrador</span>
                      </div>
                      <div class="bg-zinc-50/80 p-2.5 rounded-xl border border-zinc-200/50 flex justify-between items-center">
                          <div>
                              <span class="font-bold text-zinc-700">Recepcionista:</span>
                              <span class="block text-slate-500">recep@smartculto.com / recep2026</span>
                          </div>
                          <span class="px-2 py-0.5 bg-zinc-100 text-zinc-800 border border-zinc-200 rounded-md font-semibold text-[10px]">Recepcionista</span>
                      </div>
                  </div>
              </div>

          </div>
      </div>
      <script>
          lucide.createIcons();
      </script>
  </body>
  </html>
  `);
});

// POST Login Handler
app.post('/login.php', (req, res) => {
  const email = (req.body.email || '').trim();
  const senha = (req.body.senha || '').trim();

  if (!email || !senha) {
    return res.redirect(`/login.php?erro=${encodeURIComponent('Por favor, preencha todos os campos.')}`);
  }

  const usuarios = readJsonDB('usuarios.json');
  const user = usuarios.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (user) {
    let isValid = false;
    // Verify standard BCrypt as well as a plain text fallback
    try {
      if (bcrypt.compareSync(senha, user.senha)) {
        isValid = true;
      }
    } catch (e) {
      console.error("Bcrypt compare exception, falling back:", e);
    }

    if (!isValid && senha === user.senha) {
      isValid = true;
    }

    if (isValid) {
      const userSession = {
        nome: user.nome,
        email: user.email,
        perfil: user.perfil
      };
      
      const sessionStr = encodeURIComponent(JSON.stringify(userSession));
      res.cookie('usuario', JSON.stringify(userSession), { path: '/' });
      return res.redirect(`/home.php?usuario_session=${sessionStr}`);
    } else {
      return res.redirect(`/login.php?erro=${encodeURIComponent('Senha incorreta.')}&email=${encodeURIComponent(email)}`);
    }
  } else {
    return res.redirect(`/login.php?erro=${encodeURIComponent('Usuário não cadastrado.')}&email=${encodeURIComponent(email)}`);
  }
});


// HOME PAGE (DASHBOARD)
app.get('/home.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');

  const usersCount = readJsonDB('usuarios.json').length;
  const cultos = readJsonDB('cultos.json');
  const visitantes = readJsonDB('visitantes.json');

  const cultosCount = cultos.length;
  const visitantesCount = visitantes.length;

  // Recent cultos
  const recentCultos = [...cultos]
    .sort((a, b) => b.data.localeCompare(a.data))
    .slice(0, 3);

  let html = renderHeader(user, 'home');
  html += `
    <div class="bg-white border border-zinc-200/80 rounded-3xl p-6 sm:p-8 text-zinc-800 shadow-xs mb-8 relative overflow-hidden">
        <div class="absolute -right-16 -bottom-16 opacity-[0.03] text-zinc-900 pointer-events-none">
            <i data-lucide="church" class="w-96 h-96"></i>
        </div>
        <div class="relative z-10 max-w-2xl">
            <span class="px-2.5 py-1 bg-zinc-100 text-zinc-800 font-bold uppercase tracking-wider text-[10px] rounded-lg border border-zinc-200/50">Plataforma Ativada</span>
            <h1 class="text-2xl sm:text-3.5xl font-extrabold tracking-tight text-zinc-900 mt-3 mb-2">Bem-vindo ao SmartCulto!</h1>
            <p class="text-zinc-500 text-sm sm:text-base mb-6">Simplificando o registro de presenças e acolhimento em sua comunidade de fé com discrição e elegância.</p>
            <div class="flex flex-wrap gap-3">
                ${user.perfil === 'Recepcionista' ? `
                    <a href="/cultos/cadastrar.php" class="bg-zinc-950 text-white hover:bg-zinc-800 px-4 py-2.5 rounded-xl text-sm font-semibold shadow-xs transition-all flex items-center space-x-2">
                        <i data-lucide="plus-circle" class="w-4 h-4"></i>
                        <span>Criar Novo Culto</span>
                    </a>
                    <a href="/visitantes/cadastrar.php" class="bg-white hover:bg-zinc-50 text-zinc-700 border border-zinc-200 px-4 py-2.5 rounded-xl text-sm font-semibold shadow-xs transition-all flex items-center space-x-2">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        <span>Registrar Visitante</span>
                    </a>
                ` : `
                    <a href="/usuarios/cadastrar.php" class="bg-zinc-950 text-white hover:bg-zinc-800 px-4 py-2.5 rounded-xl text-sm font-semibold shadow-xs transition-all flex items-center space-x-2">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        <span>Cadastrar Novo Usuário</span>
                    </a>
                    <a href="/usuarios/listar.php" class="bg-white hover:bg-zinc-50 text-zinc-700 border border-zinc-200 px-4 py-2.5 rounded-xl text-sm font-semibold shadow-xs transition-all flex items-center space-x-2">
                        <i data-lucide="shield-alert" class="w-4 h-4"></i>
                        <span>Gerenciar Acessos</span>
                    </a>
                `}
            </div>
        </div>
    </div>

    <h2 class="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-4 flex items-center">
        <i data-lucide="activity" class="w-4 h-4 mr-1.5 text-zinc-500"></i>
        Métricas Gerais do Sistema
    </h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div class="bg-white p-6 rounded-2xl border border-zinc-200/80 shadow-xs flex items-center justify-between hover:border-zinc-300 transition-all">
            <div class="space-y-1">
                <p class="text-sm font-medium text-zinc-400">Total de Cultos</p>
                <p class="text-3xl font-extrabold text-zinc-950">${cultosCount}</p>
                <a href="/cultos/listar.php" class="text-xs text-zinc-500 hover:text-zinc-900 hover:underline font-semibold inline-flex items-center space-x-1 pt-1">
                    <span>Ver todos</span>
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                </a>
            </div>
            <div class="p-3 bg-zinc-50 text-zinc-900 rounded-2xl border border-zinc-200/60">
                <i data-lucide="calendar" class="w-8 h-8"></i>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-zinc-200/80 shadow-xs flex items-center justify-between hover:border-zinc-300 transition-all">
            <div class="space-y-1">
                <p class="text-sm font-medium text-zinc-400">Total de Visitantes</p>
                <p class="text-3xl font-extrabold text-zinc-950">${visitantesCount}</p>
                <a href="/visitantes/listar.php" class="text-xs text-zinc-500 hover:text-zinc-900 hover:underline font-semibold inline-flex items-center space-x-1 pt-1">
                    <span>Ver todos</span>
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                </a>
            </div>
            <div class="p-3 bg-zinc-50 text-zinc-900 rounded-2xl border border-zinc-200/60">
                <i data-lucide="users" class="w-8 h-8"></i>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-zinc-200/80 shadow-xs flex items-center justify-between hover:border-zinc-300 transition-all sm:col-span-2 lg:col-span-1">
            <div class="space-y-1">
                <p class="text-sm font-medium text-zinc-400">Operadores Ativos</p>
                <p class="text-3xl font-extrabold text-zinc-950">${usersCount}</p>
                ${user.perfil === 'ADM' ? `
                    <a href="/usuarios/listar.php" class="text-xs text-zinc-500 hover:text-zinc-900 hover:underline font-semibold inline-flex items-center space-x-1 pt-1">
                        <span>Gerenciar equipe</span>
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                    </a>
                ` : `
                    <p class="text-xs text-zinc-400 italic pt-1 flex items-center">
                        <i data-lucide="lock" class="w-3.5 h-3.5 mr-1"></i> Apenas ADM
                    </p>
                `}
            </div>
            <div class="p-3 bg-zinc-50 text-zinc-900 rounded-2xl border border-zinc-200/60">
                <i data-lucide="users-round" class="w-8 h-8"></i>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div class="lg:col-span-3 space-y-4">
            <div class="flex items-center justify-between">
                <h3 class="font-bold text-zinc-900 text-lg flex items-center">
                    <i data-lucide="calendar-days" class="w-5 h-5 mr-1.5 text-zinc-850"></i>
                    Cultos Recentes
                </h3>
                <a href="/cultos/listar.php" class="text-sm font-semibold text-zinc-500 hover:text-zinc-900 hover:underline">Ver Lista Completa</a>
            </div>

            <div class="bg-white rounded-2xl border border-zinc-200/80 shadow-xs overflow-hidden divide-y divide-zinc-100">
                ${recentCultos.length === 0 ? `
                    <div class="p-8 text-center text-zinc-400 space-y-2">
                        <i data-lucide="info" class="w-8 h-8 mx-auto text-zinc-300"></i>
                        <p class="text-sm">Nenhum culto cadastrado ainda.</p>
                        ${user.perfil === 'Recepcionista' ? `
                            <a href="/cultos/cadastrar.php" class="inline-block mt-2 text-xs font-semibold text-zinc-900 hover:underline">Cadastrar o primeiro culto agora</a>
                        ` : ''}
                    </div>
                ` : recentCultos.map(c => `
                    <div class="p-5 hover:bg-zinc-50/40 transition-all flex justify-between items-center">
                        <div class="space-y-1">
                            <h4 class="font-bold text-zinc-800 text-base">${c.tipo}</h4>
                            <div class="flex items-center space-x-4 text-xs text-zinc-400">
                                <span class="flex items-center">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5 mr-1 text-zinc-400"></i>
                                    ${formatDate(c.data)}
                                </span>
                                <span class="flex items-center">
                                    <i data-lucide="hash" class="w-3.5 h-3.5 mr-1 text-zinc-400"></i>
                                    ID: ${c.id}
                                </span>
                            </div>
                        </div>
                        <div>
                            <a href="/cultos/visualizar.php?id=${c.id}" 
                               class="px-3 py-1.5 border border-zinc-200 text-zinc-650 hover:text-zinc-900 hover:border-zinc-400 hover:bg-zinc-50 rounded-xl transition-all cursor-pointer inline-flex items-center justify-center font-semibold text-xs">
                                <i data-lucide="eye" class="w-3.5 h-3.5 mr-1"></i>
                                <span>Visualizar</span>
                            </a>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="lg:col-span-2 space-y-4">
            <h3 class="font-bold text-zinc-900 text-lg flex items-center">
                <i data-lucide="terminal" class="w-5 h-5 mr-1.5 text-zinc-850"></i>
                Permissões de Atuação
            </h3>
            <div class="bg-white p-6 rounded-2xl border border-zinc-200/80 shadow-xs space-y-4">
                <div class="flex items-center space-x-3 pb-4 border-b border-zinc-100">
                    <div class="w-10 h-10 rounded-xl bg-zinc-100 text-zinc-800 border border-zinc-200 flex items-center justify-center font-bold text-base">
                        ${user.perfil.substring(0, 1)}
                    </div>
                    <div>
                        <p class="text-sm font-semibold text-zinc-800">${user.nome}</p>
                        <p class="text-xs text-zinc-400">${user.email}</p>
                    </div>
                </div>

                <div class="space-y-3">
                    <p class="text-xs font-bold text-zinc-400 uppercase tracking-widest">Painel Operacional</p>
                    
                    ${user.perfil === 'ADM' ? `
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Gestão de Operadores</strong>: Listar e registrar novos usuários.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Redefinição de Senhas</strong>: Redefinir senhas dos operadores das equipes.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Consulta Completa</strong>: Visualizar cultos, detalhes e relatórios de visitantes.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-400">
                            <i data-lucide="lock" class="w-4 h-4 text-zinc-300 mt-0.5 shrink-0"></i>
                            <span>Criação de Cultos é restrita à Recepção.</span>
                        </div>
                    ` : `
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Criação de Cultos</strong>: Registrar novos cultos da igreja.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Recepção de Visitantes</strong>: Cadastrar e vincular novos visitantes ao culto.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-600">
                            <i data-lucide="check" class="w-4 h-4 text-zinc-800 mt-0.5 shrink-0"></i>
                            <span><strong>Consulta e Listas</strong>: Visualizar dados e cultos registrados.</span>
                        </div>
                        <div class="flex space-x-2.5 items-start text-xs text-zinc-400">
                            <i data-lucide="lock" class="w-4 h-4 text-zinc-300 mt-0.5 shrink-0"></i>
                            <span>Gestão de Operadores é restrita ao ADM.</span>
                        </div>
                    `}
                </div>
            </div>
        </div>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});


// -------------------------------------------------------------
// USER MANAGEMENT ROUTES (ADM ONLY)
// -------------------------------------------------------------

// LIST USERS
app.get('/usuarios/listar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');
  if (user.perfil !== 'ADM') return res.redirect('/home.php');

  const erro = req.query.erro ? decodeURIComponent(req.query.erro as string) : '';
  const sucesso = req.query.sucesso ? decodeURIComponent(req.query.sucesso as string) : '';

  const usuarios = readJsonDB('usuarios.json');

  let html = renderHeader(user, 'usuarios', '..');
  html += `
    ${sucesso ? `
        <div class="mb-6 p-4 bg-zinc-50 border border-zinc-200/60 rounded-xl flex items-start space-x-3 text-zinc-800">
            <i data-lucide="check-circle" class="w-5 h-5 mt-0.5 shrink-0 text-zinc-800"></i>
            <div class="text-sm font-medium">${sucesso}</div>
        </div>
    ` : ''}

    ${erro ? `
        <div class="mb-6 p-4 bg-red-50 border border-red-250/60 rounded-xl flex items-start space-x-3 text-red-900">
            <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
            <div class="text-sm font-medium">${erro}</div>
        </div>
    ` : ''}

    <div class="md:flex md:items-center md:justify-between mb-8">
        <div class="flex-1 min-w-0">
            <h2 class="text-2xl font-extrabold leading-7 text-zinc-900 sm:text-3xl sm:truncate flex items-center tracking-tight">
                <i data-lucide="users-round" class="w-8 h-8 mr-2.5 text-zinc-900"></i>
                Operadores de Equipe
            </h2>
            <p class="mt-1 text-sm text-zinc-500">Gerenciamento de acessos de Administradores e Recepcionistas.</p>
        </div>
        <div class="mt-4 flex md:mt-0 md:ml-4">
            <a href="/usuarios/cadastrar.php" class="inline-flex items-center justify-center px-4 py-2.5 border border-transparent rounded-xl shadow-xs text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-900 transition-all cursor-pointer">
                <i data-lucide="user-plus" class="w-4 h-4 mr-2"></i>
                Registrar Operador
            </a>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-zinc-200/85 shadow-xs overflow-hidden mb-8">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-zinc-200/50 text-left">
                <thead class="bg-zinc-50">
                    <tr>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Nome</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Email</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Cargo / Perfil</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider text-right">Ação</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-150/50 bg-white">
                    ${usuarios.length === 0 ? `
                        <tr>
                            <td colspan="4" class="px-6 py-12 text-center text-zinc-400">
                                <i data-lucide="info" class="w-8 h-8 mx-auto text-zinc-300 mb-2"></i>
                                <p class="text-sm">Nenhum operador cadastrado no momento.</p>
                            </td>
                        </tr>
                    ` : usuarios.map(u => `
                        <tr class="hover:bg-zinc-50/40 transition-all">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-zinc-100 text-zinc-900 border border-zinc-200 mr-3">
                                        ${u.nome.substring(0, 1).toUpperCase()}
                                    </div>
                                    <span class="text-sm font-semibold text-zinc-800">${u.nome}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-500">
                                ${u.email}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                <span class="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider border ${u.perfil === 'ADM' ? 'bg-zinc-100 text-zinc-800 border-zinc-200' : 'bg-zinc-50 text-zinc-700 border-zinc-200'}">
                                    ${u.perfil}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button onclick="abrirModalRedefinir('${u.email}')" 
                                        class="inline-flex items-center space-x-1 text-xs font-semibold text-zinc-700 hover:text-zinc-950 bg-white hover:bg-zinc-100 px-3 py-1.5 border border-zinc-200 rounded-xl transition-all cursor-pointer">
                                    <i data-lucide="key-round" class="w-3.5 h-3.5"></i>
                                    <span>Alterar Senha</span>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </div>

    <!-- Reset Password Modal Background -->
    <div id="redefinirModal" class="fixed inset-0 bg-zinc-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 hidden">
        <div class="bg-white rounded-2xl shadow-xs border border-zinc-250/60 max-w-md w-full overflow-hidden transform scale-95 transition-all" id="modalContainer">
            <div class="px-6 py-5 bg-zinc-50 border-b border-zinc-100 flex items-center justify-between">
                <div class="flex items-center space-x-2 text-zinc-950 font-bold">
                    <i data-lucide="key-round" class="w-5 h-5 text-zinc-900"></i>
                    <span>Alterar Senha do Operador</span>
                </div>
                <button onclick="fecharModalRedefinir()" class="text-zinc-400 hover:text-zinc-900 p-1.5 rounded-lg hover:bg-zinc-100 transition-all cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form action="/usuarios/listar.php" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="acao" value="redefinir_senha">
                
                <div>
                    <label class="block text-xs font-bold uppercase tracking-widest text-zinc-400 mb-1">Email do Operador</label>
                    <input type="text" id="modalEmailDisplay" class="block w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-650 text-sm font-semibold focus:outline-none cursor-not-allowed" readonly>
                    <input type="hidden" name="email" id="modalEmailValue">
                </div>

                <div>
                    <label for="nova_senha" class="block text-xs font-bold uppercase tracking-widest text-zinc-500 mb-1">Nova Senha Provisória</label>
                    <input type="password" id="nova_senha" name="nova_senha" required placeholder="Digite a nova senha provisória"
                           class="block w-full px-4 py-2.5 border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 focus:border-zinc-950 text-sm transition-all bg-zinc-50/10">
                </div>

                <div class="flex space-x-3 pt-4 border-t border-zinc-100">
                    <button type="button" onclick="fecharModalRedefinir()" 
                            class="flex-1 justify-center py-2.5 px-4 border border-zinc-200 rounded-xl text-sm font-semibold text-zinc-650 hover:bg-zinc-50 focus:outline-none transition-all cursor-pointer text-center">
                        Cancelar
                    </button>
                    <button type="submit" 
                            class="flex-1 justify-center py-2.5 px-4 border border-transparent rounded-xl text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none transition-all cursor-pointer shadow-xs">
                        Salvar Nova Senha
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function abrirModalRedefinir(email) {
            document.getElementById('modalEmailDisplay').value = email;
            document.getElementById('modalEmailValue').value = email;
            
            const modal = document.getElementById('redefinirModal');
            modal.classList.remove('hidden');
            setTimeout(() => {
                document.getElementById('modalContainer').classList.remove('scale-95');
                document.getElementById('modalContainer').classList.add('scale-100');
            }, 50);
        }

        function fecharModalRedefinir() {
            document.getElementById('modalContainer').classList.remove('scale-100');
            document.getElementById('modalContainer').classList.add('scale-95');
            setTimeout(() => {
                document.getElementById('redefinirModal').classList.add('hidden');
                document.getElementById('nova_senha').value = '';
            }, 200);
        }
    </script>
  `;
  html += renderFooter();
  res.send(html);
});

// POST RESET PASSWORD INTERACTION
app.post('/usuarios/listar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user || user.perfil !== 'ADM') return res.sendStatus(403);

  const acao = req.body.acao;
  if (acao === 'redefinir_senha') {
    const email = (req.body.email || '').trim();
    const novaSenha = (req.body.nova_senha || '').trim();

    if (!email || !novaSenha) {
      return res.redirect('/usuarios/listar.php?erro=' + encodeURIComponent('Todos os campos são de preenchimento obrigatório.'));
    }

    const usuarios = readJsonDB('usuarios.json');
    const userIndex = usuarios.findIndex(u => u.email === email);

    if (userIndex !== -1) {
      // safe bcrypt hash
      usuarios[userIndex].senha = bcrypt.hashSync(novaSenha, 10);
      if (writeJsonDB('usuarios.json', usuarios)) {
        return res.redirect('/usuarios/listar.php?sucesso=' + encodeURIComponent(`A senha do operador ${email} foi alterada com sucesso!`));
      } else {
        return res.redirect('/usuarios/listar.php?erro=' + encodeURIComponent('Falha ao escrever no banco de dados.'));
      }
    } else {
      return res.redirect('/usuarios/listar.php?erro=' + encodeURIComponent('Operador não encontrado.'));
    }
  }

  res.redirect('/usuarios/listar.php');
});

// CADASTRAR USER (FORM)
app.get('/usuarios/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');
  if (user.perfil !== 'ADM') return res.redirect('/home.php');

  const erro = req.query.erro ? decodeURIComponent(req.query.erro as string) : '';
  const preNome = req.query.nome ? decodeURIComponent(req.query.nome as string) : '';
  const preEmail = req.query.email ? decodeURIComponent(req.query.email as string) : '';

  let html = renderHeader(user, 'usuarios', '..');
  html += `
    <nav class="flex mb-6 text-xs font-semibold text-zinc-400" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="/home.php" class="hover:text-zinc-900 flex items-center transition-all">
                    <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                    Início
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <a href="/usuarios/listar.php" class="ml-1 md:ml-2 hover:text-zinc-900 transition-all">Usuários</a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <span class="ml-1 md:ml-2 text-zinc-650">Novo Operador</span>
                </div>
            </li>
        </ol>
    </nav>

    ${erro ? `
        <div class="mb-6 p-4 bg-red-50 border border-red-200/50 rounded-xl flex items-start space-x-3 text-red-900">
            <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
            <div class="text-sm font-medium">${erro}</div>
        </div>
    ` : ''}

    <div class="bg-white rounded-2xl border border-zinc-200/80 shadow-xs overflow-hidden">
        <div class="px-6 py-5 bg-zinc-50 border-b border-zinc-150/60 flex items-center space-x-2.5">
            <div class="p-2 bg-zinc-900 text-white rounded-xl">
                <i data-lucide="user-plus" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold tracking-tight text-zinc-900">Cadastrar Novo Operador</h3>
                <p class="text-xs text-zinc-500">Crie credenciais de acesso para recepcionistas ou administradores.</p>
            </div>
        </div>

        <form action="/usuarios/cadastrar.php" method="POST" class="p-6 space-y-5">
            <div>
                <label for="nome" class="block text-sm font-semibold text-zinc-700">Nome Completo</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="user" class="w-4 h-4"></i>
                    </div>
                    <input type="text" id="nome" name="nome" required 
                           class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                           placeholder="João da Silva" value="${preNome}">
                </div>
            </div>

            <div>
                <label for="email" class="block text-sm font-semibold text-zinc-700">Email Acadêmico / Equipe</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input type="email" id="email" name="email" required 
                           class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                           placeholder="joao@igreja.com" value="${preEmail}">
                </div>
            </div>

            <div>
                <label for="senha" class="block text-sm font-semibold text-zinc-700">Senha Provisória</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="lock" class="w-4 h-4"></i>
                    </div>
                    <input type="password" id="senha" name="senha" required 
                           class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                           placeholder="Crie uma senha de acesso provisória">
                </div>
            </div>

            <div>
                <label for="perfil" class="block text-sm font-semibold text-zinc-700">Nível de Permissão (Perfil)</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="badge-check" class="w-4 h-4"></i>
                    </div>
                    <select id="perfil" name="perfil" required 
                            class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/15 cursor-pointer select-none">
                        <option value="">Selecione o perfil de atuação...</option>
                        <option value="Recepcionista">Recepcionista (Recepção & Cultos)</option>
                        <option value="ADM">ADM (Administração Completa)</option>
                    </select>
                </div>
            </div>

            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-150/60">
                <a href="/usuarios/listar.php" 
                   class="px-5 py-2.5 border border-zinc-200 rounded-xl text-sm font-semibold text-zinc-650 hover:bg-zinc-50 hover:text-zinc-900 focus:outline-none transition-all cursor-pointer">
                    Cancelar
                </a>
                <button type="submit" 
                        class="px-5 py-2.5 border border-transparent rounded-xl shadow-xs text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-950 transition-all cursor-pointer">
                    Confirmar Cadastro
                </button>
            </div>
        </form>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});

// POST CADASTRAR USER
app.post('/usuarios/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user || user.perfil !== 'ADM') return res.sendStatus(403);

  const nome = (req.body.nome || '').trim();
  const email = (req.body.email || '').trim();
  const senha = (req.body.senha || '').trim();
  const perfil = (req.body.perfil || '').trim();

  const erroRedirect = (msg: string) => {
    return res.redirect(`/usuarios/cadastrar.php?erro=${encodeURIComponent(msg)}&nome=${encodeURIComponent(nome)}&email=${encodeURIComponent(email)}`);
  };

  if (!nome || !email || !senha || !perfil) {
    return erroRedirect('Todos os campos de cadastro são de preenchimento obrigatório.');
  }

  if (perfil !== 'ADM' && perfil !== 'Recepcionista') {
    return erroRedirect('Perfil de acesso inválido.');
  }

  const usuarios = readJsonDB('usuarios.json');
  const emailExiste = usuarios.some(u => u.email.toLowerCase() === email.toLowerCase());

  if (emailExiste) {
    return erroRedirect('Este email já está cadastrado por outro operador.');
  }

  const novoUsuario = {
    nome,
    email,
    senha: bcrypt.hashSync(senha, 10),
    perfil
  };

  usuarios.push(novoUsuario);

  if (writeJsonDB('usuarios.json', usuarios)) {
    return res.redirect('/usuarios/listar.php?sucesso=' + encodeURIComponent(`Operador ${nome} foi cadastrado com sucesso!`));
  } else {
    return erroRedirect('Falha ao gravar os dados do novo operador.');
  }
});


// -------------------------------------------------------------
// WORSHIP SERVICES (CULTOS) MODULE LOGIC
// -------------------------------------------------------------

// LIST CULTOS
app.get('/cultos/listar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');

  const cultos = readJsonDB('cultos.json').sort((a, b) => b.data.localeCompare(a.data));

  let html = renderHeader(user, 'cultos', '..');
  html += `
    <div class="md:flex md:items-center md:justify-between mb-8">
        <div class="flex-1 min-w-0">
            <h2 class="text-2xl font-extrabold leading-7 text-zinc-900 sm:text-3xl sm:truncate flex items-center tracking-tight">
                <i data-lucide="church" class="w-8 h-8 mr-2.5 text-zinc-900"></i>
                Cultos Registrados
            </h2>
            <p class="mt-1 text-sm text-zinc-500">Lista geral de cultos realizados ou agendados na igreja.</p>
        </div>
        
        <div class="mt-4 flex md:mt-0 md:ml-4">
            ${user.perfil === 'Recepcionista' ? `
                <a href="/cultos/cadastrar.php" class="inline-flex items-center justify-center px-4 py-2.5 border border-transparent rounded-xl shadow-xs text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-950 transition-all cursor-pointer">
                    <i data-lucide="plus-circle" class="w-4 h-4 mr-2"></i>
                    Novo Culto
                </a>
            ` : `
                <div class="inline-flex items-center space-x-1.5 px-3 py-2 bg-zinc-50 text-zinc-500 text-xs font-semibold rounded-xl border border-zinc-200/60">
                    <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                    <span>Apenas Recepcionistas criam cultos</span>
                </div>
            `}
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-zinc-200/85 shadow-xs overflow-hidden mb-8">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-zinc-200/50 text-left">
                <thead class="bg-zinc-50">
                    <tr>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">ID</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Tipo do Culto</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Data do Encontro</th>
                        <th scope="col" class="px-0 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider text-right pr-6">Ação</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-150/50 bg-white">
                    ${cultos.length === 0 ? `
                        <tr>
                            <td colspan="4" class="px-6 py-16 text-center text-zinc-400">
                                <i data-lucide="calendar-off" class="w-10 h-10 mx-auto text-zinc-300 mb-2"></i>
                                <p class="text-sm font-semibold text-zinc-650">Nenhum culto cadastrado.</p>
                                <p class="text-xs text-zinc-450 mt-1">Utilize a conta de Recepcionista para criar o primeiro encontro de culto.</p>
                            </td>
                        </tr>
                    ` : cultos.map(c => `
                        <tr class="hover:bg-zinc-50/40 transition-all">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-zinc-400">
                                #${c.id}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-lg flex items-center justify-center bg-zinc-100 text-zinc-900 border border-zinc-200/60 mr-3">
                                        <i data-lucide="church" class="w-4 h-4"></i>
                                    </div>
                                    <span class="text-sm font-extrabold text-zinc-900">${c.tipo}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-650 font-semibold">
                                <div class="flex items-center space-x-1.5">
                                    <i data-lucide="clock" class="w-4 h-4 text-zinc-400"></i>
                                    <span>${formatDate(c.data)}</span>
                                </div>
                            </td>
                            <td class="px-0 py-4 whitespace-nowrap text-right text-sm font-semibold pr-6 animate-none">
                                <a href="/cultos/visualizar.php?id=${c.id}" 
                                   class="inline-flex items-center space-x-1.5 text-xs font-semibold text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 transition-all cursor-pointer">
                                    <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                    <span>Visualizar Visitantes</span>
                                </a>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});

// CADASTRAR CULTO (FORM)
app.get('/cultos/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');
  if (user.perfil !== 'Recepcionista') return res.redirect('/cultos/listar.php');

  const erro = req.query.erro ? decodeURIComponent(req.query.erro as string) : '';
  const preTipo = req.query.tipo ? decodeURIComponent(req.query.tipo as string) : '';

  let html = renderHeader(user, 'cultos', '..');
  html += `
    <nav class="flex mb-6 text-xs font-semibold text-zinc-400" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="/home.php" class="hover:text-zinc-900 flex items-center transition-all">
                    <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                    Início
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <a href="/cultos/listar.php" class="ml-1 md:ml-2 hover:text-zinc-900 transition-all">Cultos</a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <span class="ml-1 md:ml-2 text-zinc-650">Novo Culto</span>
                </div>
            </li>
        </ol>
    </nav>

    ${erro ? `
        <div class="mb-6 p-4 bg-red-50 border border-red-200/50 rounded-xl flex items-start space-x-3 text-red-900">
            <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
            <div class="text-sm font-medium">${erro}</div>
        </div>
    ` : ''}

    <div class="bg-white rounded-2xl border border-zinc-200/80 shadow-xs overflow-hidden">
        <div class="px-6 py-5 bg-zinc-50 border-b border-zinc-150/60 flex items-center space-x-2.5">
            <div class="p-2 bg-zinc-900 text-white rounded-xl">
                <i data-lucide="plus-circle" class="w-5 h-5"></i>
            </div>
            <div>
                <h3 class="text-base font-extrabold tracking-tight text-zinc-900">Agendar / Criar Novo Culto</h3>
                <p class="text-xs text-zinc-500">Defina o tipo e a data de ocorrência do culto.</p>
            </div>
        </div>

        <form action="/cultos/cadastrar.php" method="POST" class="p-6 space-y-5">
            <div>
                <label for="tipo" class="block text-sm font-semibold text-zinc-700">Tipo de Culto</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="book-open" class="w-4 h-4"></i>
                    </div>
                    <input type="text" id="tipo" name="tipo" required 
                           class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                           placeholder="Ex: Culto de Celebração, Culto de Ensino, Reunião de Jovens" value="${preTipo}">
                </div>
            </div>

            <div>
                <label for="data" class="block text-sm font-semibold text-zinc-700">Data de Realização</label>
                <div class="mt-1 relative rounded-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                    </div>
                    <input type="date" id="data" name="data" required 
                           class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-white cursor-pointer" 
                           value="${new Date().toISOString().substring(0, 10)}">
                </div>
            </div>

            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-150/60 font-semibold">
                <a href="/cultos/listar.php" 
                   class="px-5 py-2.5 border border-zinc-200 rounded-xl text-sm text-zinc-650 hover:bg-zinc-50 hover:text-zinc-900 focus:outline-none transition-all cursor-pointer">
                    Cancelar
                </a>
                <button type="submit" 
                        class="px-5 py-2.5 border border-transparent rounded-xl shadow-xs text-sm text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-950 transition-all cursor-pointer">
                    Confirmar Criação
                </button>
            </div>
        </form>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});

// POST CADASTRAR CULTO
app.post('/cultos/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user || user.perfil !== 'Recepcionista') return res.sendStatus(403);

  const tipo = (req.body.tipo || '').trim();
  const data = (req.body.data || '').trim();

  if (!tipo || !data) {
    return res.redirect(`/cultos/cadastrar.php?erro=${encodeURIComponent('Por favor, preencha todos os campos.')}&tipo=${encodeURIComponent(tipo)}`);
  }

  const cultos = readJsonDB('cultos.json');

  // Find max ID inside JSON array to mimic auto_increment
  const maxId = cultos.reduce((max, c) => (c.id > max ? c.id : max), 0);
  const newId = maxId + 1;

  const novoCulto = {
    id: newId,
    tipo,
    data
  };

  cultos.push(novoCulto);

  if (writeJsonDB('cultos.json', cultos)) {
    return res.redirect('/cultos/listar.php');
  } else {
    return res.redirect(`/cultos/cadastrar.php?erro=${encodeURIComponent('Erro ao salvar no arquivo de dados.')}&tipo=${encodeURIComponent(tipo)}`);
  }
});

// VISUALIZAR CULTO
app.get('/cultos/visualizar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');

  const id = parseInt(req.query.id as string || '0');
  if (id <= 0) return res.redirect('/cultos/listar.php');

  const cultos = readJsonDB('cultos.json');
  const culto = cultos.find(c => c.id === id);

  if (!culto) return res.redirect('/cultos/listar.php');

  const visitantes = readJsonDB('visitantes.json');
  const visitantesDesteCulto = visitantes.filter(v => parseInt(v.culto_id) === id);

  const totalEvangelicos = visitantesDesteCulto.filter(v => v.evangelico === 'Sim').length;
  const totalNaoEvangelicos = visitantesDesteCulto.length - totalEvangelicos;
  const numVisitantes = visitantesDesteCulto.length;

  let html = renderHeader(user, 'cultos', '..');
  html += `
    <nav class="flex mb-6 text-xs font-semibold text-zinc-400" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="/home.php" class="hover:text-zinc-900 flex items-center transition-all">
                    <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                    Início
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <a href="/cultos/listar.php" class="ml-1 md:ml-2 hover:text-zinc-900 transition-all">Cultos</a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <span class="ml-1 md:ml-2 text-zinc-650">Detalhes do Culto</span>
                </div>
            </li>
        </ol>
    </nav>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        
        <div class="lg:col-span-2 bg-zinc-900 rounded-3xl p-6 sm:p-8 text-white border border-zinc-850 flex flex-col justify-between relative overflow-hidden shadow-xs">
            <div class="absolute -right-8 -bottom-8 opacity-[0.03] text-white pointer-events-none">
                <i data-lucide="church" class="w-48 h-48"></i>
            </div>
            <div class="relative z-10">
                <span class="px-2.5 py-1 bg-zinc-850 text-zinc-300 border border-zinc-700 font-bold uppercase tracking-wider text-[10px] rounded-lg">Ficha de Reunião</span>
                <h2 class="text-2xl sm:text-3.5xl font-extrabold tracking-tight mt-2.5 mb-2">
                    ${culto.tipo}
                </h2>
                <div class="flex flex-wrap gap-x-6 gap-y-2 mt-4 text-sm text-zinc-400 font-medium">
                    <span class="flex items-center">
                        <i data-lucide="calendar" class="w-4 text-zinc-500 mr-2"></i>
                        Data: ${formatDate(culto.data)}
                    </span>
                    <span class="flex items-center">
                        <i data-lucide="hash" class="w-4 text-zinc-500 mr-2"></i>
                        Identificador único: #${culto.id}
                    </span>
                </div>
            </div>
            
            <div class="relative z-10 flex flex-wrap gap-2 pt-6">
                <a href="/cultos/listar.php" class="bg-zinc-800 hover:bg-zinc-750 text-zinc-100 border border-zinc-700/80 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    <span>Voltar para Lista</span>
                </a>
                
                ${user.perfil === 'Recepcionista' ? `
                    <a href="/visitantes/cadastrar.php?culto_id=${culto.id}" class="bg-white text-zinc-950 hover:bg-zinc-100 px-4 py-2 rounded-xl text-xs font-extrabold shadow-sm transition-all flex items-center space-x-1.5">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        <span>Adicionar Visitante</span>
                    </a>
                ` : ''}
            </div>
        </div>

        <div class="bg-white rounded-3xl p-6 border border-zinc-200/85 shadow-xs flex flex-col justify-between">
            <div>
                <h3 class="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-4 flex items-center">
                    <i data-lucide="bar-chart-3" class="w-4 h-4 mr-1.5 text-zinc-900"></i>
                    Relatório do Culto
                </h3>
                
                <div class="space-y-4">
                    <div class="flex justify-between items-end border-b border-zinc-100 pb-2.5">
                        <span class="text-sm font-semibold text-zinc-500">Visitantes Inscritos</span>
                        <span class="text-2.5xl font-extrabold text-zinc-950">${numVisitantes}</span>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4 pt-2">
                        <div class="bg-zinc-50 p-3 rounded-2xl border border-zinc-200/60 text-center">
                            <span class="block text-[10px] font-bold text-zinc-500 uppercase">Evangélicos</span>
                            <span class="text-xl font-extrabold text-zinc-900 mt-1 block">${totalEvangelicos}</span>
                        </div>
                        <div class="bg-zinc-50 p-3 rounded-2xl border border-zinc-200/60 text-center">
                            <span class="block text-[10px] font-bold text-zinc-500 uppercase">Novas Visitas</span>
                            <span class="text-xl font-extrabold text-zinc-900 mt-1 block">${totalNaoEvangelicos}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4">
                <span class="block text-[10px] font-bold text-zinc-400 uppercase mb-1.5">Perfil Religioso de Visitantes</span>
                <div class="w-full bg-zinc-100 h-2.5 rounded-full flex overflow-hidden">
                    ${numVisitantes > 0 ? `
                        <div class="bg-zinc-950 h-full" style="width: ${(totalEvangelicos / numVisitantes) * 100}%"></div>
                        <div class="bg-zinc-300 h-full" style="width: ${(totalNaoEvangelicos / numVisitantes) * 100}%"></div>
                    ` : `
                        <div class="bg-zinc-200 w-full h-full"></div>
                    `}
                </div>
                <div class="flex justify-between items-center text-[10px] text-zinc-400 font-semibold mt-1">
                    <span class="flex items-center"><span class="w-2 h-2 rounded bg-zinc-950 mr-1.5"></span>Evangélicos</span>
                    <span class="flex items-center">Não Evangélicos<span class="w-2 h-2 rounded bg-zinc-300 ml-1.5"></span></span>
                </div>
            </div>

        </div>

    </div>

    <h3 class="font-extrabold text-zinc-900 text-lg flex items-center mb-4 tracking-tight">
        <i data-lucide="users" class="w-5 h-5 mr-1.5 text-zinc-900"></i>
        Visitantes na Recepção
    </h3>

    <div class="bg-white rounded-2xl border border-zinc-200/85 shadow-xs overflow-hidden mb-8">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-zinc-200/50 text-left">
                <thead class="bg-zinc-50">
                    <tr>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Nome do Visitante</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Membro Evangélico</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Congregação de Origem</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Denominação</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-150/50 bg-white">
                    ${visitantesDesteCulto.length === 0 ? `
                        <tr>
                            <td colspan="4" class="px-6 py-12 text-center text-zinc-400">
                                <i data-lucide="user-minus" class="w-8 h-8 mx-auto text-zinc-300 mb-2"></i>
                                <p class="text-sm font-semibold text-zinc-650">Nenhum visitante registrado para este culto.</p>
                                ${user.perfil === 'Recepcionista' ? `
                                    <a href="/visitantes/cadastrar.php?culto_id=${culto.id}" class="inline-block mt-2 text-xs font-semibold text-zinc-900 hover:underline">Adicionar o primeiro visitante agora</a>
                                ` : ''}
                            </td>
                        </tr>
                    ` : visitantesDesteCulto.map(v => `
                        <tr class="hover:bg-zinc-50/40 transition-all w-full">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-zinc-100 text-zinc-900 border border-zinc-200 mr-3">
                                        ${v.nome.substring(0, 1).toUpperCase()}
                                    </div>
                                    <span class="text-sm font-bold text-zinc-805 text-zinc-800">${v.nome}</span>
                                </div>
                            </td>
                            
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-650 font-semibold">
                                ${v.evangelico === 'Sim' ? `
                                    <span class="px-2.5 py-1 bg-zinc-150/40 text-zinc-800 rounded-md text-xs font-bold tracking-wide inline-flex items-center border border-zinc-200">
                                        <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
                                        Sim
                                    </span>
                                ` : `
                                    <span class="px-2.5 py-1 bg-zinc-50 text-zinc-500 rounded-md text-xs font-bold tracking-wide inline-flex items-center border border-zinc-200/50">
                                        <i data-lucide="help-circle" class="w-3.5 h-3.5 mr-1"></i>
                                        Não (Visita)
                                    </span>
                                `}
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-500/90 font-medium">
                                ${v.evangelico === 'Sim' ? htmlspecialchars(v.congregacao || 'Sem registro') : '<span class="text-zinc-300 italic">-</span>'}
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-500/90 font-medium">
                                ${v.evangelico === 'Sim' ? htmlspecialchars(v.denominacao || 'Sem registro') : '<span class="text-zinc-300 italic">-</span>'}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});


// -------------------------------------------------------------
// VISITORS MODULE LOGIC (ADM & RECEPCIONISTA)
// -------------------------------------------------------------

// LIST VISITORS
app.get('/visitantes/listar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');

  const visitantes = readJsonDB('visitantes.json');
  const cultos = readJsonDB('cultos.json');

  // Build a lookup map of cultos in Node.js
  const cultosMap: { [key: number]: { tipo: string, data: string } } = {};
  cultos.forEach(c => {
    cultosMap[c.id] = {
      tipo: c.tipo,
      data: formatDate(c.data)
    };
  });

  let html = renderHeader(user, 'visitantes', '..');
  html += `
    <div class="md:flex md:items-center md:justify-between mb-8">
        <div class="flex-1 min-w-0">
            <h2 class="text-2xl font-extrabold leading-7 text-zinc-900 sm:text-3xl sm:truncate flex items-center tracking-tight">
                <i data-lucide="users" class="w-8 h-8 mr-2.5 text-zinc-900"></i>
                Visitantes Acolhidos
            </h2>
            <p class="mt-1 text-sm text-zinc-500">Lista geral de visitantes acolhidos pelos recepcionistas em nossa comunidade.</p>
        </div>
        
        <div class="mt-4 flex md:mt-0 md:ml-4">
            ${user.perfil === 'Recepcionista' ? `
                <a href="/visitantes/cadastrar.php" class="inline-flex items-center justify-center px-4 py-2.5 border border-transparent rounded-xl shadow-xs text-sm font-semibold text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-950 transition-all cursor-pointer">
                    <i data-lucide="user-plus" class="w-4 h-4 mr-2"></i>
                    Novo Visitante
                </a>
            ` : `
                <div class="inline-flex items-center space-x-1.5 px-3 py-2 bg-zinc-50 text-zinc-500 text-xs font-semibold rounded-xl border border-zinc-200/60">
                    <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                    <span>Apenas Recepcionistas adicionam visitantes</span>
                </div>
            `}
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-zinc-200/85 shadow-xs overflow-hidden mb-8">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-zinc-200/50 text-left">
                <thead class="bg-zinc-50">
                    <tr>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Nome Completo</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Membro Evangélico?</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Congregação / Denominação</th>
                        <th scope="col" class="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Culto / Encontro Visitado</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-150/50 bg-white">
                    ${visitantes.length === 0 ? `
                        <tr>
                            <td colspan="4" class="px-6 py-16 text-center text-zinc-400">
                                <i data-lucide="user-x" class="w-10 h-10 mx-auto text-zinc-300 mb-2"></i>
                                <p class="text-sm font-semibold text-zinc-650">Nenhum visitante cadastrado no momento.</p>
                                <p class="text-xs text-zinc-450 mt-1">Utilize o login de Recepcionista para registrar novos visitantes na recepção.</p>
                            </td>
                        </tr>
                    ` : visitantes.map(v => {
                        const cId = parseInt(v.culto_id);
                        const cDetail = cultosMap[cId];
                        return `
                        <tr class="hover:bg-zinc-50/40 transition-all w-full">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm bg-zinc-100 text-zinc-900 border border-zinc-200 mr-3">
                                        ${v.nome.substring(0, 1).toUpperCase()}
                                    </div>
                                    <span class="text-sm font-bold text-zinc-800">${v.nome}</span>
                                </div>
                            </td>
                            
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                ${v.evangelico === 'Sim' ? `
                                    <span class="px-2.5 py-1 bg-zinc-150/40 text-zinc-805 rounded-md text-xs font-bold tracking-wide inline-flex items-center border border-zinc-200">
                                        <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
                                        Sim
                                    </span>
                                ` : `
                                    <span class="px-2.5 py-1 bg-zinc-50 text-zinc-500 rounded-md text-xs font-bold tracking-wide inline-flex items-center border border-zinc-200/50">
                                        <i data-lucide="help-circle" class="w-3.5 h-3.5 mr-1"></i>
                                        Não (Visita)
                                    </span>
                                `}
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap text-sm text-zinc-650 font-medium animate-none">
                                ${v.evangelico === 'Sim' ? `
                                    <span class="font-semibold text-zinc-700">${v.congregacao || 'Sem registro'}</span>
                                    <span class="text-[11px] text-zinc-400">(${v.denominacao || 'Outra'})</span>
                                ` : '<span class="text-zinc-300 italic">-</span>'}
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold">
                                ${cDetail ? `
                                    <a href="/cultos/visualizar.php?id=${cId}" class="text-zinc-900 hover:text-zinc-650 hover:underline font-bold transition-all">
                                        ${cDetail.tipo}
                                        <span class="text-xs font-normal text-zinc-400">(${cDetail.data})</span>
                                    </a>
                                ` : `<span class="text-zinc-400 italic font-normal">Culto ID #${cId} (Inexistente)</span>`}
                            </td>
                        </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    </div>
  `;
  html += renderFooter();
  res.send(html);
});

// CADASTRAR VISITANTE (FORM)
app.get('/visitantes/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.redirect('/login.php');
  if (user.perfil !== 'Recepcionista') return res.redirect('/visitantes/listar.php');

  const erro = req.query.erro ? decodeURIComponent(req.query.erro as string) : '';
  const preNome = req.query.nome ? decodeURIComponent(req.query.nome as string) : '';
  const preCongregacao = req.query.congregacao ? decodeURIComponent(req.query.congregacao as string) : '';
  const preDenominacao = req.query.denominacao ? decodeURIComponent(req.query.denominacao as string) : '';

  const queryCultoId = parseInt(req.query.culto_id as string || '0');

  const cultos = readJsonDB('cultos.json').sort((a, b) => b.data.localeCompare(a.data));

  let html = renderHeader(user, 'visitantes', '..');
  html += `
    <nav class="flex mb-6 text-xs font-semibold text-zinc-400" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="/home.php" class="hover:text-zinc-900 flex items-center transition-all">
                    <i data-lucide="home" class="w-3.5 h-3.5 mr-1.5"></i>
                    Início
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <a href="/visitantes/listar.php" class="ml-1 md:ml-2 hover:text-zinc-900 transition-all">Visitantes</a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-zinc-300"></i>
                    <span class="ml-1 md:ml-2 text-zinc-650">Novo Visitante</span>
                </div>
            </li>
        </ol>
    </nav>

    ${erro ? `
        <div class="mb-6 p-4 bg-red-50 border border-red-200/50 rounded-xl flex items-start space-x-3 text-red-900">
            <i data-lucide="alert-circle" class="w-5 h-5 mt-0.5 shrink-0"></i>
            <div class="text-sm font-medium">${erro}</div>
        </div>
    ` : ''}

    ${cultos.length === 0 ? `
        <div class="bg-zinc-50 border border-zinc-200 rounded-2xl p-6 text-center space-y-4 shadow-xs">
            <i data-lucide="calendar-warning" class="w-12 h-12 mx-auto text-zinc-900"></i>
            <h3 class="font-extrabold text-zinc-900 text-base">Nenhum Culto Agendado no Banco</h3>
            <p class="text-xs text-zinc-500 leading-relaxed max-w-sm mx-auto">
                Você deve agendar ou cadastrar ao menos um culto no sistema antes de poder associar novos visitantes.
            </p>
            <div>
                <a href="/cultos/cadastrar.php" class="inline-flex items-center justify-center px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-semibold rounded-xl transition-all shadow-xs cursor-pointer">
                    <i data-lucide="plus" class="w-4 h-4 mr-1"></i>
                    Cadastrar Primeiro Culto
                </a>
            </div>
        </div>
    ` : `
        <div class="bg-white rounded-2xl border border-zinc-200/80 shadow-xs overflow-hidden">
            <div class="px-6 py-5 bg-zinc-50 border-b border-zinc-150/60 flex items-center space-x-2.5">
                <div class="p-2 bg-zinc-900 text-white rounded-xl">
                    <i data-lucide="user-plus" class="w-5 h-5"></i>
                </div>
                <div>
                    <h3 class="text-base font-extrabold tracking-tight text-zinc-900">Acolher & Registrar Visitante</h3>
                    <p class="text-xs text-zinc-500">Registre visitantes na recepção e associe-os a um culto ativo.</p>
                </div>
            </div>

            <form action="/visitantes/cadastrar.php" method="POST" class="p-6 space-y-5">
                <div>
                    <label for="nome" class="block text-sm font-semibold text-zinc-700">Nome Completo do Visitante</label>
                    <div class="mt-1 relative rounded-md">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                            <i data-lucide="user" class="w-4 h-4"></i>
                        </div>
                        <input type="text" id="nome" name="nome" required 
                               class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                               placeholder="Nome completo do convidado" value="${preNome}">
                    </div>
                </div>

                <div>
                    <label for="culto_id" class="block text-sm font-semibold text-zinc-700">Culto de Presença</label>
                    <div class="mt-1 relative rounded-md">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                            <i data-lucide="church" class="w-4 h-4"></i>
                        </div>
                        <select id="culto_id" name="culto_id" required 
                                class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-white cursor-pointer select-none">
                            <option value="">Selecione o culto...</option>
                            ${cultos.map(c => {
                               const isSelected = (queryCultoId === c.id) ? 'selected' : '';
                               return `<option value="${c.id}" ${isSelected}>${c.tipo} - ${formatDate(c.data)}</option>`;
                            }).join('')}
                        </select>
                    </div>
                </div>

                <div>
                    <label for="evangelico" class="block text-sm font-semibold text-zinc-700">Convidado é Evangélico?</label>
                    <div class="mt-1 relative rounded-md">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                            <i data-lucide="sparkles" class="w-4 h-4"></i>
                        </div>
                        <select id="evangelico" name="evangelico" required onchange="toggleReligiaoFields()"
                                class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-white cursor-pointer select-none">
                            <option value="Não">Não (Novo Visitante / Convidado)</option>
                            <option value="Sim">Sim (Membro de outra congregação)</option>
                        </select>
                    </div>
                </div>

                <div id="evangelico-wrapper" class="hidden space-y-5 border-l-2 border-zinc-200 pl-4 py-1.5 transition-all">
                    <div>
                        <label for="congregacao" class="block text-sm font-semibold text-zinc-700">Congregação de Membresia</label>
                        <div class="mt-1 relative rounded-md">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                                <i data-lucide="milestone" class="w-4 h-4"></i>
                            </div>
                            <input type="text" id="congregacao" name="congregacao" 
                                   class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                                   placeholder="Nome da igreja local de origem" value="${preCongregacao}">
                        </div>
                    </div>

                    <div>
                        <label for="denominacao" class="block text-sm font-semibold text-zinc-700">Denominação Religiosa</label>
                        <div class="mt-1 relative rounded-md">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                                <i data-lucide="tags" class="w-4 h-4"></i>
                            </div>
                            <input type="text" id="denominacao" name="denominacao" 
                                   class="block w-full pl-10 pr-3 py-2.5 border border-zinc-350 focus:border-zinc-950 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-950 text-sm transition-all bg-zinc-50/10" 
                                   placeholder="Ex: Assembleia de Deus, Batista, Presbiteriana" value="${preDenominacao}">
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-150/60 font-semibold">
                    <a href="/visitantes/listar.php" 
                       class="px-5 py-2.5 border border-zinc-200 rounded-xl text-sm text-zinc-650 hover:bg-zinc-50 hover:text-zinc-900 focus:outline-none transition-all cursor-pointer">
                        Cancelar
                    </a>
                    <button type="submit" 
                            class="px-5 py-2.5 border border-transparent rounded-xl shadow-xs text-sm text-white bg-zinc-950 hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zinc-950 transition-all cursor-pointer">
                        Confirmar Registro
                    </button>
                </div>
            </form>
        </div>
    `}

    <script>
        function toggleReligiaoFields() {
            const select = document.getElementById('evangelico');
            const wrapper = document.getElementById('evangelico-wrapper');
            const inputCong = document.getElementById('congregacao');
            const inputDen = document.getElementById('denominacao');

            if (select.value === 'Sim') {
                wrapper.classList.remove('hidden');
                inputCong.setAttribute('required', 'required');
                inputDen.setAttribute('required', 'required');
            } else {
                wrapper.classList.add('hidden');
                inputCong.removeAttribute('required');
                inputDen.removeAttribute('required');
                inputCong.value = '';
                inputDen.value = '';
            }
        }
    </script>
  `;
  html += renderFooter();
  res.send(html);
});

// POST CADASTRAR VISITANTE
app.post('/visitantes/cadastrar.php', (req, res) => {
  const user = getSessionUser(req);
  if (!user || user.perfil !== 'Recepcionista') return res.sendStatus(403);

  const nome = (req.body.nome || '').trim();
  const evangelico = req.body.evangelico || 'Não';
  const congregacao = (req.body.congregacao || '').trim();
  const denominacao = (req.body.denominacao || '').trim();
  const cultoId = parseInt(req.body.culto_id || '0');

  const erroRedirect = (msg: string) => {
    return res.redirect(`/visitantes/cadastrar.php?erro=${encodeURIComponent(msg)}&nome=${encodeURIComponent(nome)}&congregacao=${encodeURIComponent(congregacao)}&denominacao=${encodeURIComponent(denominacao)}&culto_id=${cultoId}`);
  };

  if (!nome || cultoId <= 0) {
    return erroRedirect('Os campos Nome e Culto são de preenchimento obrigatório.');
  }

  if (evangelico === 'Sim' && (!congregacao || !denominacao)) {
    return erroRedirect('Ao marcar Sim para evangélico, defina a congregação e a denominação de origem.');
  }

  const visitantes = readJsonDB('visitantes.json');

  const novoVisitante = {
    nome,
    evangelico,
    congregacao: (evangelico === 'Sim') ? congregacao : '',
    denominacao: (evangelico === 'Sim') ? denominacao : '',
    culto_id: cultoId
  };

  visitantes.push(novoVisitante);

  if (writeJsonDB('visitantes.json', visitantes)) {
    return res.redirect(`/cultos/visualizar.php?id=${cultoId}`);
  } else {
    return erroRedirect('Falha ao gravar os dados do visitante no arquivo JSON.');
  }
});


// Helper functions for safely rendering html entities to prevent injections
function htmlspecialchars(str: string): string {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Ensure the application listens on port 3000
app.listen(PORT, '0.0.0.0', () => {
  console.log(`SmartCulto Node.js custom runner running on http://0.0.0.0:${PORT}`);
});
